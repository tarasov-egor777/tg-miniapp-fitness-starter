# Интеграция Webapp → n8n Webhook

## Как это работает

```
Telegram Mini App (webapp)
    ↓
Отправка данных через fetch()
    ↓
n8n Webhook (POST запрос)
    ↓
Обработка в n8n workflow
    ↓
Сохранение в Supabase
```

## Настройка

### 1. В webapp/.env

Добавьте URL вашего n8n webhook:

```env
VITE_WEBHOOK_URL=https://your-n8n-instance.com/webhook/submit-profile
```

### 2. В n8n

Создайте workflow с Webhook триггером (см. `n8n/SETUP_STEP_BY_STEP.md`)

### 3. Формат данных

Webapp отправляет POST запрос с таким JSON:

```json
{
  "type": "submit_profile",
  "timestamp": "2024-01-01T12:00:00.000Z",
  "user": {
    "id": 123456789,
    "username": "username",
    "first_name": "Имя"
  },
  "profile": {
    "sex": "Мужчина",
    "height_cm": 180,
    "weight_kg": 75,
    "age": 30,
    "activity_level": "Умеренная",
    "training_per_week": 4,
    "goal": "Похудеть",
    "grains": ["Гречка", "Рис"],
    "allergies": [],
    "dietary_restrictions": [],
    "cooking_frequency": "Каждый день"
  },
  "contact": {
    "name": "Имя",
    "email": "email@example.com",
    "phone": "+79991234567"
  }
}
```

## Код отправки

В `webapp/src/App.jsx`:

```javascript
// Формируем payload
const payload = {
  type: 'submit_profile',
  timestamp: new Date().toISOString(),
  user: userData,
  profile: formData,
  contact: contactData
};

// Отправляем на n8n webhook
const result = await sendToWebhook(payload);
```

В `webapp/src/telegram.js`:

```javascript
export async function sendToWebhook(payload) {
  const webhookUrl = import.meta.env.VITE_WEBHOOK_URL;
  
  const response = await fetch(webhookUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  });
  
  return await response.json();
}
```

## Тестирование

### Локально (без Telegram)

1. Запустите webapp: `cd webapp && npm run dev`
2. Откройте в браузере: `http://localhost:3000`
3. Заполните анкету
4. Данные отправятся на n8n webhook

### В Telegram

1. Задеплойте webapp (Vercel/Netlify)
2. Настройте Web App URL в BotFather
3. Откройте бота в Telegram
4. Заполните анкету
5. Данные отправятся на n8n webhook

## Отладка

### Проверка отправки данных

Откройте DevTools (F12) → Console и Network:

1. **Console** - увидите логи отправки
2. **Network** - увидите POST запрос на webhook
3. Проверьте статус ответа (должен быть 200)

### Проверка получения в n8n

1. Откройте n8n workflow
2. Нажмите **"Execute Workflow"**
3. Проверьте данные в каждой ноде
4. Убедитесь, что данные доходят до Supabase

### Типичные ошибки

- **404 Not Found**: Неправильный URL webhook
- **CORS error**: n8n должен разрешать запросы с вашего домена
- **401 Unauthorized**: Проблемы с переменными окружения в n8n
- **500 Internal Server Error**: Ошибка в workflow (проверьте логи)

## Альтернатива: через Telegram Bot

Если хотите использовать `Telegram.WebApp.sendData()`:

1. Настройте бота на получение данных через `sendData`
2. Бот должен пересылать данные на n8n webhook
3. Или обрабатывать данные напрямую в боте

Но проще использовать прямую отправку на webhook - так надежнее.

