# Полная интеграция оплаты и передачи данных

## Схема полного потока данных

```
┌─────────────────┐
│  Telegram Mini  │
│      App        │
└────────┬────────┘
         │
         │ 1. Отправка анкеты
         ▼
┌─────────────────┐
│  n8n Webhook    │
│ submit-profile  │
└────────┬────────┘
         │
         │ 2. Сохранение профиля
         ▼
┌─────────────────┐
│   Supabase      │
│   profiles      │
└─────────────────┘
         │
         │ 3. Возврат profile_id
         ▼
┌─────────────────┐
│  Telegram Mini  │
│      App        │
└────────┬────────┘
         │
         │ 4. Показ инвойса
         ▼
┌─────────────────┐
│ Telegram Payments│
└────────┬────────┘
         │
         │ 5. Подтверждение оплаты
         ▼
┌─────────────────┐
│  n8n Webhook    │
│payment-confirm  │
└────────┬────────┘
         │
         │ 6. Сохранение платежа
         ▼
┌─────────────────┐
│   Supabase      │
│   payments      │
└────────┬────────┘
         │
         │ 7. Получение профиля
         ▼
┌─────────────────┐
│   AI Agent      │
│  Генерация плана│
└────────┬────────┘
         │
         │ 8. Сохранение плана
         ▼
┌─────────────────┐
│   Supabase      │
│    plans        │
└────────┬────────┘
         │
         │ 9. Отправка PDF
         ▼
┌─────────────────┐
│ Telegram Bot API│
│  sendDocument   │
└─────────────────┘
```

## Что настроено

### ✅ 1. Webapp → n8n (Анкета)

**Файл:** `webapp/src/App.jsx`

- ✅ Отправка данных профиля на webhook `/submit-profile`
- ✅ Обработка ответа с `profile_id`
- ✅ Показ кнопки оплаты после успешной отправки

**Данные отправляются:**
```json
{
  "type": "submit_profile",
  "user": { "id": 123456789, ... },
  "profile": { "sex": "Мужчина", "height_cm": 180, ... },
  "contact": { "name": "...", "email": "..." }
}
```

### ✅ 2. Webapp → Telegram Payments (Оплата)

**Файл:** `webapp/src/payment.js`

- ✅ Создание инвойса через `Telegram.WebApp.openInvoice()`
- ✅ Обработка статуса оплаты (paid/failed/cancelled)
- ✅ Отправка подтверждения на webhook `/payment-confirm`

**Инвойс:**
```javascript
{
  title: 'Персональный план питания',
  description: '...',
  currency: 'RUB',
  prices: [{ label: '...', amount: 199000 }], // в копейках
  payload: JSON.stringify({ type: 'meal_plan_payment', profileId: '...' })
}
```

### ✅ 3. n8n Webhook → Supabase (Сохранение)

**Файл:** `n8n/workflow-complete.json`

- ✅ Webhook `/submit-profile` → сохранение в `profiles`
- ✅ Webhook `/payment-confirm` → сохранение в `payments`
- ✅ Возврат `profile_id` после сохранения профиля

### ✅ 4. n8n → AI Agent → Генерация плана

**Файл:** `n8n/workflow-with-ai.json`

- ✅ После оплаты → получение профиля
- ✅ AI Agent генерирует план с использованием:
  - Calculate KBJU Tool
  - Search Recipes Tool (векторный поиск)
  - Generate Meal Plan Tool
- ✅ Сохранение плана в `plans`

### ✅ 5. n8n → Telegram Bot API (Отправка PDF)

**Добавьте в workflow после генерации PDF:**

```javascript
// Нода HTTP Request
Method: POST
URL: https://api.telegram.org/bot{{ $env.TELEGRAM_BOT_TOKEN }}/sendDocument
Body: {
  "chat_id": "{{ $('Get Profile').item.json.telegramUserId }}",
  "document": "{{ $binary.data }}",
  "caption": "Ваш персональный план питания готов! 🎉"
}
```

## Настройка переменных окружения

### Webapp (.env)

```env
VITE_WEBHOOK_URL=https://your-n8n-instance.com/webhook
VITE_MEAL_PLAN_PRICE=1990
```

### n8n (Environment Variables)

```env
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_KEY=your_service_key
TELEGRAM_BOT_TOKEN=your_bot_token
PDF_API_URL=https://api.html2pdf.app/v1/generate
```

## Полный workflow с оплатой

### Вариант 1: Два отдельных workflow

1. **Workflow 1:** Обработка анкеты (`submit-profile`)
   - Принимает анкету
   - Сохраняет профиль
   - Возвращает `profile_id`

2. **Workflow 2:** Обработка оплаты и генерация (`payment-confirm`)
   - Принимает подтверждение оплаты
   - Сохраняет платеж
   - Генерирует план через AI Agent
   - Отправляет PDF через Telegram Bot API

### Вариант 2: Один workflow с двумя webhook'ами

Используйте `workflow-complete.json` - там два webhook'а:
- `/submit-profile` - для анкеты
- `/payment-confirm` - для оплаты

После оплаты workflow автоматически:
1. Сохраняет платеж
2. Получает профиль
3. Запускает генерацию плана (нужно добавить AI Agent часть)

## Интеграция с Telegram Payments

### Настройка в BotFather

1. Откройте [@BotFather](https://t.me/BotFather)
2. Выполните команду `/mybots`
3. Выберите вашего бота
4. Выберите **Payments**
5. Настройте провайдера платежей:
   - Для России: ЮKassa, Stripe, и т.д.
   - Загрузите документы (если требуется)
   - Получите `provider_token`

### Использование в коде

В `webapp/src/payment.js` добавьте `provider_token`:

```javascript
const invoice = {
  // ... другие поля
  provider_token: import.meta.env.VITE_PAYMENT_PROVIDER_TOKEN || '',
  // ...
};
```

Или получайте токен с сервера через webhook перед показом инвойса.

## Обработка ошибок

### В webapp

```javascript
try {
  const result = await showInvoice(invoice);
  // Обработка успешной оплаты
} catch (error) {
  if (error.message === 'Payment cancelled') {
    // Пользователь отменил оплату
  } else if (error.message === 'Payment failed') {
    // Ошибка оплаты
    showAlert('Ошибка оплаты. Попробуйте еще раз.');
  }
}
```

### В n8n

Добавьте обработку ошибок в workflow:

1. **IF нода** после Save Payment
   - Если `status === 'paid'` → продолжаем генерацию
   - Если `status === 'failed'` → отправляем уведомление

2. **Error handling** в AI Agent
   - Если генерация не удалась → отправляем сообщение пользователю
   - Логируем ошибку для отладки

## Тестирование полного потока

### 1. Тест отправки анкеты

```bash
curl -X POST https://your-n8n.com/webhook/submit-profile \
  -H "Content-Type: application/json" \
  -d '{
    "profile": {
      "sex": "Мужчина",
      "height_cm": 180,
      "weight_kg": 75,
      "age": 30,
      "goal": "Похудеть",
      ...
    },
    "user": { "id": 123456789 },
    "contact": { "name": "Тест", "email": "test@test.com" }
  }'
```

Ожидаемый ответ:
```json
{
  "success": true,
  "profile_id": "uuid-here",
  "message": "Профиль сохранен. Ожидайте оплаты."
}
```

### 2. Тест подтверждения оплаты

```bash
curl -X POST https://your-n8n.com/webhook/payment-confirm \
  -H "Content-Type: application/json" \
  -d '{
    "profileId": "uuid-from-step-1",
    "amount": 1990,
    "currency": "RUB",
    "paymentMethod": "telegram",
    "status": "paid"
  }'
```

Ожидаемый результат:
- Платеж сохранен в `payments`
- Профиль получен
- Запущена генерация плана
- PDF отправлен пользователю

## Чеклист интеграции

- [x] Webapp отправляет анкету на webhook
- [x] n8n сохраняет профиль в Supabase
- [x] Webapp показывает инвойс для оплаты
- [x] Webapp отправляет подтверждение оплаты
- [x] n8n сохраняет платеж в Supabase
- [x] n8n генерирует план через AI Agent
- [x] n8n отправляет PDF через Telegram Bot API
- [ ] Настроить провайдера платежей в BotFather
- [ ] Добавить обработку ошибок
- [ ] Добавить логирование
- [ ] Настроить уведомления пользователю

## Дополнительные улучшения

1. **Статусы планов:**
   - `pending_payment` - ожидает оплаты
   - `processing` - генерируется
   - `ready` - готов к отправке
   - `sent` - отправлен пользователю

2. **Повторная отправка PDF:**
   - Добавьте команду в бота `/get_plan`
   - Проверяйте наличие плана в БД
   - Отправляйте PDF повторно

3. **Уведомления:**
   - Отправляйте уведомление когда план готов
   - Уведомляйте об ошибках генерации

Все файлы готовы! Осталось только настроить провайдера платежей и протестировать полный поток.

