import { describe, it, expect } from 'vitest';
import { calculateTarget, mifflinStJeor, activityMultiplier, type Profile } from '../src/calculator';

describe('calculator', () => {
  describe('mifflinStJeor', () => {
    it('calculates BMR for male', () => {
      const profile: Profile = {
        sex: 'Мужчина',
        weight_kg: 80,
        height_cm: 180,
        age: 30,
        goal: 'Поддержание веса'
      };
      const bmr = mifflinStJeor(profile);
      // Ожидаемое значение: (10*80) + (6.25*180) - (5*30) + 5 = 800 + 1125 - 150 + 5 = 1780
      expect(bmr).toBe(1780);
    });

    it('calculates BMR for female', () => {
      const profile: Profile = {
        sex: 'Женщина',
        weight_kg: 65,
        height_cm: 165,
        age: 25,
        goal: 'Поддержание веса'
      };
      const bmr = mifflinStJeor(profile);
      // Ожидаемое значение: (10*65) + (6.25*165) - (5*25) - 161 = 650 + 1031.25 - 125 - 161 = 1395.25 ≈ 1395
      expect(bmr).toBe(1395);
    });
  });

  describe('activityMultiplier', () => {
    it('returns correct multiplier for sedentary', () => {
      expect(activityMultiplier('Сидячая работа')).toBe(1.2);
    });

    it('returns correct multiplier for moderate activity', () => {
      expect(activityMultiplier('Умеренная')).toBe(1.55);
    });

    it('returns correct multiplier for high activity', () => {
      expect(activityMultiplier('Высокая')).toBe(1.725);
    });
  });

  describe('calculateTarget', () => {
    it('calculates for male with weight loss goal', () => {
      const profile: Profile = {
        sex: 'Мужчина',
        weight_kg: 80,
        height_cm: 180,
        age: 30,
        activity_level: 'Умеренная',
        training_per_week: 4,
        goal: 'Похудеть'
      };
      const result = calculateTarget(profile);
      
      expect(result).toHaveProperty('bmr');
      expect(result).toHaveProperty('tdee');
      expect(result).toHaveProperty('target_kcal');
      expect(result).toHaveProperty('macros');
      
      expect(result.bmr).toBeGreaterThan(0);
      expect(result.tdee).toBeGreaterThan(result.bmr);
      expect(result.target_kcal).toBeLessThan(result.tdee); // Дефицит для похудения
      
      expect(result.macros.protein_g).toBeGreaterThan(0);
      expect(result.macros.fats_g).toBeGreaterThan(0);
      expect(result.macros.carbs_g).toBeGreaterThan(0);
    });

    it('calculates for female with weight gain goal', () => {
      const profile: Profile = {
        sex: 'Женщина',
        weight_kg: 60,
        height_cm: 170,
        age: 28,
        activity_level: 'Небольшая активность',
        training_per_week: 3,
        goal: 'Набрать массу'
      };
      const result = calculateTarget(profile);
      
      expect(result.target_kcal).toBeGreaterThan(result.tdee); // Профицит для набора массы
      expect(result.macros.protein_g).toBeGreaterThan(0);
    });

    it('calculates for maintenance goal', () => {
      const profile: Profile = {
        sex: 'Мужчина',
        weight_kg: 75,
        height_cm: 175,
        age: 35,
        activity_level: 'Сидячая работа',
        goal: 'Поддержание веса'
      };
      const result = calculateTarget(profile);
      
      // При поддержании веса целевые калории должны быть близки к TDEE
      expect(Math.abs(result.target_kcal - result.tdee)).toBeLessThan(10);
    });

    it('calculates for cutting goal', () => {
      const profile: Profile = {
        sex: 'Мужчина',
        weight_kg: 85,
        height_cm: 185,
        age: 32,
        activity_level: 'Высокая',
        goal: 'Сушка'
      };
      const result = calculateTarget(profile);
      
      // При сушке дефицит должен быть больше, чем при обычном похудении
      expect(result.target_kcal).toBeLessThan(result.tdee * 0.85);
    });

    it('throws error for invalid profile', () => {
      const invalidProfile: Profile = {
        sex: 'Мужчина',
        weight_kg: -10,
        height_cm: 180,
        age: 30,
        goal: 'Поддержание веса'
      };
      
      expect(() => calculateTarget(invalidProfile)).toThrow();
    });

    it('uses default activity level when not provided', () => {
      const profile: Profile = {
        sex: 'Мужчина',
        weight_kg: 80,
        height_cm: 180,
        age: 30,
        goal: 'Поддержание веса'
      };
      const result = calculateTarget(profile);
      
      // Должен использовать 'Сидячая работа' (multiplier 1.2)
      expect(result.tdee).toBe(Math.round(result.bmr * 1.2));
    });
  });

  describe('macros calculation', () => {
    it('distributes macros correctly (P30/F25/C45)', () => {
      const profile: Profile = {
        sex: 'Мужчина',
        weight_kg: 80,
        height_cm: 180,
        age: 30,
        activity_level: 'Умеренная',
        goal: 'Поддержание веса'
      };
      const result = calculateTarget(profile);
      
      // Проверяем, что сумма калорий из макронутриентов близка к целевым калориям
      const calculatedKcal = (result.macros.protein_g * 4) + 
                            (result.macros.fats_g * 9) + 
                            (result.macros.carbs_g * 4);
      
      // Допускаем погрешность в 50 ккал из-за округления
      expect(Math.abs(calculatedKcal - result.target_kcal)).toBeLessThan(50);
    });
  });
});


