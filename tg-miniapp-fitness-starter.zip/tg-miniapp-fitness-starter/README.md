# TG MiniApp Fitness Starter

Telegram Mini App для сервиса подбора индивидуальных планов питания для фитнес-тренеров.

## Архитектура

- **Frontend**: Telegram Web App (React + Vite) — мультишаговая анкета
- **Backend**: Node.js/TypeScript — калькулятор КБЖУ и API endpoints
- **База данных**: PostgreSQL (Supabase) — пользователи, профили, рецепты, планы
- **Оркестратор**: n8n — webhook → валидация → расчёт → генерация PDF → отправка
- **Платежи**: Telegram Payments / Stripe (через n8n)

## Структура проекта

```
tg-miniapp-fitness-starter/
├── webapp/          # React Web App для Telegram
├── api/             # Backend API (TypeScript)
├── infra/           # SQL миграции для Supabase
├── n8n/             # n8n workflow экспорты
└── README.md        # Этот файл
```

## 📦 Экспорт проекта из Cursor

**Важно!** Если вы работаете в Cursor и хотите запустить проект локально:

1. **Скопируйте проект** вручную через Finder/Проводник или используйте терминал:
   ```bash
   cp -r /Users/tarasovegor/tg-miniapp-fitness-starter ~/Desktop/tg-miniapp-fitness-starter
   ```

2. Подробные инструкции см. в файле **[EXPORT_INSTRUCTIONS.md](./EXPORT_INSTRUCTIONS.md)**

## 🚨 Проблема с импортом n8n workflow?

Если при импорте `n8n/workflow.json` возникает ошибка `undefined is not a function`:

1. Используйте упрощенную версию: `n8n/workflow-simple.json`
2. Или создайте workflow вручную - см. **[n8n/IMPORT_GUIDE.md](./n8n/IMPORT_GUIDE.md)**

## Быстрый старт

### 1. Настройка переменных окружения

Скопируйте `.env.example` в `.env` и заполните значения:

```bash
# Supabase
SUPABASE_URL=your_supabase_url
SUPABASE_ANON_KEY=your_anon_key
SUPABASE_SERVICE_KEY=your_service_key  # Только для backend!

# Telegram
TELEGRAM_BOT_TOKEN=your_bot_token

# Платежи (опционально)
STRIPE_SECRET=your_stripe_secret

# Storage (опционально)
S3_BUCKET=your_bucket
S3_KEY=your_key
S3_SECRET=your_secret
```

### 2. Установка зависимостей

```bash
# Frontend
cd webapp
npm install
npm run dev

# Backend
cd api
npm install
npm test  # Запуск тестов калькулятора
```

### 3. Настройка Supabase

1. Создайте проект в [Supabase](https://supabase.com)
2. Выполните миграции из `infra/migrations/001_init.sql` в SQL Editor
3. Скопируйте URL и ключи в `.env`

### 4. Настройка Telegram Bot

1. Создайте бота через [@BotFather](https://t.me/BotFather)
2. Получите токен и добавьте в `.env`
3. Настройте Web App URL (после деплоя frontend)
4. Опционально: настройте Telegram Payments в BotFather

### 5. Настройка n8n

1. Импортируйте `n8n/workflow.json` в ваш n8n instance
2. Настройте webhook URL на ваш публичный endpoint
3. Заполните переменные окружения в n8n (Supabase, Telegram Bot Token)

## Разработка

### Web App (Frontend)

```bash
cd webapp
npm run dev      # Запуск dev-сервера
npm run build    # Production сборка
npm run preview  # Превью production сборки
```

**Важные файлы:**
- `src/App.jsx` — главный компонент
- `src/components/StepForm.jsx` — мультишаговая форма анкеты
- `src/telegram.js` — интеграция с Telegram.WebApp API

### API (Backend)

```bash
cd api
npm test         # Запуск unit-тестов
```

**Модули:**
- `src/calculator.ts` — расчёт КБЖУ (Mifflin-St Jeor)
- `src/index.ts` — HTTP endpoints (stub)

### Тестирование калькулятора

```bash
cd api
npm test
```

Тесты проверяют корректность расчёта BMR, TDEE и макронутриентов.

## Алгоритм расчёта КБЖУ

1. **BMR** (базовый метаболизм) — формула Mifflin-St Jeor
2. **TDEE** (общий расход энергии) — BMR × коэффициент активности
3. **Целевые калории** — TDEE с учётом цели (дефицит/избыток)
4. **Макронутриенты** — распределение по соотношению P30/F25/C45

## Безопасность

- ✅ Service Role ключ Supabase — только в backend/n8n (никогда в frontend!)
- ✅ Telegram Bot Token — хранить в secrets/environment variables
- ✅ PII данные — шифрование в БД, доступ по ролям
- ✅ Telegram SecureStorage — для чувствительных данных в Mini App

## Деплой

### Frontend (Vercel/Netlify)

```bash
cd webapp
npm run build
# Загрузите dist/ в ваш хостинг
```

### Backend (Vercel Functions / Railway / Render)

```bash
cd api
# Настройте serverless функцию или Node.js сервер
```

### n8n

Используйте облачный n8n или self-hosted версию.

## Следующие шаги

1. ✅ Заполните базу рецептов в Supabase
2. ✅ Настройте генерацию эмбеддингов для векторного поиска
3. ✅ Реализуйте генерацию PDF (puppeteer/docx)
4. ✅ Настройте платежи (Telegram Payments или Stripe)
5. ✅ Добавьте A/B тесты и метрики

## Полезные ссылки

- [Telegram Bot API](https://core.telegram.org/bots/api)
- [Telegram Mini Apps](https://core.telegram.org/bots/webapps)
- [Supabase Docs](https://supabase.com/docs)
- [n8n Docs](https://docs.n8n.io)

## Лицензия

MIT

