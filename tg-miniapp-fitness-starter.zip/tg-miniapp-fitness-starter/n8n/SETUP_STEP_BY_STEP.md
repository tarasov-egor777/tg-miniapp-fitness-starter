# Пошаговая настройка n8n workflow (БЕЗ ИМПОРТА JSON)

Если импорт JSON не работает, создайте workflow вручную - это займет 5 минут и гарантированно сработает.

## Шаг 1: Создайте новый workflow

1. Откройте n8n
2. Нажмите **"+ Add workflow"**
3. Назовите: **"Telegram Mini App Fitness"**

## Шаг 2: Добавьте Webhook триггер

1. Перетащите ноду **"Webhook"** на canvas
2. Настройте:
   - **HTTP Method**: `POST`
   - **Path**: `submit-profile`
   - **Response Mode**: `Respond to Webhook`
3. Нажмите **"Execute Node"** чтобы получить URL
4. **Скопируйте Production URL** - он понадобится для webapp!

URL будет выглядеть так:
```
https://your-n8n-instance.com/webhook/submit-profile
```

## Шаг 3: Добавьте Code ноду для обработки данных

1. Перетащите ноду **"Code"** после Webhook
2. Соедините Webhook → Code
3. Вставьте этот код:

```javascript
// Получаем данные из webhook
const body = $input.item.json.body || $input.item.json;

// Извлекаем нужные данные
const profile = body.profile || {};
const user = body.user || {};
const contact = body.contact || {};

// Возвращаем структурированные данные
return {
  profile: {
    sex: profile.sex,
    height_cm: profile.height_cm,
    weight_kg: profile.weight_kg,
    age: profile.age,
    activity_level: profile.activity_level,
    training_per_week: profile.training_per_week || 0,
    goal: profile.goal,
    grains: profile.grains || [],
    allergies: profile.allergies || [],
    dietary_restrictions: profile.dietary_restrictions || [],
    cooking_frequency: profile.cooking_frequency || 'Каждый день'
  },
  user: {
    id: user.id,
    username: user.username,
    first_name: user.first_name
  },
  contact: {
    name: contact.name,
    email: contact.email,
    phone: contact.phone
  }
};
```

## Шаг 4: Добавьте HTTP Request для Supabase

1. Перетащите ноду **"HTTP Request"** после Code
2. Соедините Code → HTTP Request
3. Настройте:

**Basic Settings:**
- **Method**: `POST`
- **URL**: `{{ $env.SUPABASE_URL }}/rest/v1/profiles`

**Headers:**
Добавьте 3 заголовка:
1. `apikey` = `{{ $env.SUPABASE_ANON_KEY }}`
2. `Authorization` = `Bearer {{ $env.SUPABASE_SERVICE_KEY }}`
3. `Content-Type` = `application/json`
4. `Prefer` = `return=representation`

**Body:**
- **Body Content Type**: `JSON`
- **JSON Body**: Вставьте это:

```json
{
  "sex": "{{ $json.profile.sex }}",
  "height_cm": {{ $json.profile.height_cm }},
  "weight_kg": {{ $json.profile.weight_kg }},
  "age": {{ $json.profile.age }},
  "activity_level": "{{ $json.profile.activity_level }}",
  "training_per_week": {{ $json.profile.training_per_week }},
  "goal": "{{ $json.profile.goal }}",
  "preferences": {
    "grains": {{ JSON.stringify($json.profile.grains) }},
    "allergies": {{ JSON.stringify($json.profile.allergies) }},
    "dietary_restrictions": {{ JSON.stringify($json.profile.dietary_restrictions) }},
    "cooking_frequency": "{{ $json.profile.cooking_frequency }}"
  }
}
```

## Шаг 5: Добавьте Respond to Webhook

1. Перетащите ноду **"Respond to Webhook"** в конце
2. Соедините HTTP Request → Respond to Webhook
3. Настройте:
   - **Respond With**: `JSON`
   - **Response Body**:

```json
{
  "success": true,
  "profile_id": "{{ $json.id }}"
}
```

## Шаг 6: Настройте переменные окружения

1. В n8n откройте **Settings** → **Environment Variables**
2. Добавьте переменные:

```
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_ANON_KEY=your_anon_key_here
SUPABASE_SERVICE_KEY=your_service_role_key_here
```

## Шаг 7: Активируйте workflow

1. Переключите тумблер **"Active"** в положение **ON**
2. Workflow готов к работе!

## Шаг 8: Настройте webapp

В файле `webapp/.env` добавьте:

```env
VITE_WEBHOOK_URL=https://your-n8n-instance.com/webhook/submit-profile
```

## Тестирование

### Тест 1: Проверка webhook

Откройте терминал и выполните:

```bash
curl -X POST https://your-n8n-instance.com/webhook/submit-profile \
  -H "Content-Type: application/json" \
  -d '{
    "profile": {
      "sex": "Мужчина",
      "height_cm": 180,
      "weight_kg": 75,
      "age": 30,
      "activity_level": "Умеренная",
      "training_per_week": 4,
      "goal": "Похудеть",
      "grains": ["Гречка", "Рис"],
      "allergies": [],
      "dietary_restrictions": [],
      "cooking_frequency": "Каждый день"
    },
    "user": {
      "id": 123456789
    },
    "contact": {
      "name": "Тест",
      "email": "test@example.com"
    }
  }'
```

Должен вернуться ответ:
```json
{
  "success": true,
  "profile_id": "uuid-здесь"
}
```

### Тест 2: Проверка в webapp

1. Запустите webapp: `cd webapp && npm run dev`
2. Заполните анкету
3. Нажмите "Отправить"
4. Проверьте в n8n, что workflow выполнился
5. Проверьте в Supabase, что данные сохранились

## Структура данных, которую отправляет webapp

```json
{
  "type": "submit_profile",
  "timestamp": "2024-01-01T12:00:00.000Z",
  "user": {
    "id": 123456789,
    "username": "username",
    "first_name": "Имя",
    "last_name": "Фамилия"
  },
  "profile": {
    "sex": "Мужчина",
    "height_cm": 180,
    "weight_kg": 75,
    "age": 30,
    "activity_level": "Умеренная",
    "training_per_week": 4,
    "goal": "Похудеть",
    "grains": ["Гречка", "Рис"],
    "allergies": ["Молочные продукты"],
    "dietary_restrictions": ["Вегетарианство"],
    "cooking_frequency": "Каждый день"
  },
  "contact": {
    "name": "Имя Фамилия",
    "email": "email@example.com",
    "phone": "+79991234567"
  }
}
```

## Дополнительные шаги (опционально)

После базового workflow можно добавить:

1. **HTTP Request** → вызов калькулятора КБЖУ (ваш API)
2. **Code** → поиск рецептов из Supabase
3. **HTTP Request** → генерация PDF
4. **HTTP Request** → отправка через Telegram Bot API

Но для начала достаточно базового workflow - он сохранит данные в Supabase.

## Проблемы?

- **Webhook не получает данные**: Проверьте URL в `webapp/.env`
- **Ошибка при сохранении в Supabase**: Проверьте переменные окружения и права доступа
- **Workflow не активируется**: Убедитесь, что тумблер "Active" включен

