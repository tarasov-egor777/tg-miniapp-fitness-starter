# Настройка AI Agent для генерации планов питания

## Проблемы в вашем текущем workflow

1. **AI Agent неправильно настроен** - инструменты не подключены корректно
2. **Векторный поиск не работает** - неправильная конфигурация Supabase Vector Store
3. **Слишком сложная структура** - много disabled нод
4. **Нет интеграции с webapp** - используется Telegram Trigger вместо Webhook

## Правильная структура AI Agent

### 1. Создайте новый workflow

Импортируйте `workflow-with-ai.json` или создайте вручную:

### 2. Настройте инструменты (Tools)

#### A. Calculate KBJU Tool (Code Tool)

```javascript
// Параметры от AI агента
const gender = $fromAI('gender', 'User gender: male or female', 'string');
const age = $fromAI('age', 'User age in years', 'number');
const height = $fromAI('height', 'User height in cm', 'number');
const weight = $fromAI('weight', 'User weight in kg', 'number');
const activityLevel = $fromAI('activityLevel', 'Activity coefficient', 'number');
const goal = $fromAI('goal', 'User goal: weight_loss, maintenance, muscle_gain', 'string');

// Расчет BMR по Mifflin-St Jeor
let bmr;
if (gender.toLowerCase() === 'male' || gender === 'Мужчина') {
  bmr = 10 * weight + 6.25 * height - 5 * age + 5;
} else {
  bmr = 10 * weight + 6.25 * height - 5 * age - 161;
}

const tdee = bmr * activityLevel;
let targetCalories = tdee;
if (goal === 'weight_loss' || goal === 'Похудеть') {
  targetCalories = tdee * 0.85;
} else if (goal === 'muscle_gain' || goal === 'Набрать массу') {
  targetCalories = tdee * 1.15;
}

// Макронутриенты P30/F25/C45
const protein = Math.round((targetCalories * 0.30) / 4);
const fat = Math.round((targetCalories * 0.25) / 9);
const carbs = Math.round((targetCalories * 0.45) / 4);

return {
  bmr: Math.round(bmr),
  tdee: Math.round(tdee),
  targetCalories: Math.round(targetCalories),
  macros: { protein, fat, carbs }
};
```

**Важно:** Используйте `$fromAI()` для получения параметров от агента!

#### B. Search Recipes Tool (Vector Store)

1. Создайте ноду **Supabase Vector Store**
2. Настройте:
   - **Mode**: `Retrieve as Tool`
   - **Table Name**: `recipes_vector` (ваша таблица с эмбеддингами)
   - **Top K**: 5-10 (количество результатов)
3. Подключите **OpenAI Embeddings**:
   - **Model**: `text-embedding-ada-002`
4. Подключите к AI Agent как `ai_tool`

#### C. Generate Meal Plan Tool (Code Tool)

```javascript
const targetCalories = $fromAI('targetCalories', 'Target daily calories', 'number');
const protein = $fromAI('protein', 'Target protein in grams', 'number');
const recipes = $fromAI('recipes', 'Recipes from database (JSON)', 'string');

// Парсим рецепты
let recipeData = [];
try {
  recipeData = typeof recipes === 'string' ? JSON.parse(recipes) : recipes;
} catch (e) {
  recipeData = [];
}

// Генерируем план на основе рецептов
const mealPlan = {
  dailyTargets: { calories: targetCalories, protein: protein },
  weeklyPlan: [
    // Используйте рецепты из recipeData
  ]
};

return { mealPlan: JSON.stringify(mealPlan) };
```

### 3. Настройте AI Agent

1. Создайте ноду **Agent** (LangChain)
2. **Prompt Type**: `Define Below`
3. **System Message**:

```
Ты - эксперт по питанию. Твоя задача - создавать персонализированные планы питания.

Инструкции:
1. ВСЕГДА сначала используй Calculate KBJU Tool для расчета калорий
2. Затем используй Search Recipes Tool для поиска рецептов
3. Используй Generate Meal Plan Tool для создания плана
4. Учитывай все предпочтения и ограничения пользователя
5. Используй РЕАЛЬНЫЕ рецепты из базы данных
```

4. **User Message** (динамический):

```
Создай план питания для:
Пол: {{ $json.profile.sex }}
Рост: {{ $json.profile.height_cm }} см
Вес: {{ $json.profile.weight_kg }} кг
Возраст: {{ $json.profile.age }} лет
Цель: {{ $json.profile.goal }}
Аллергии: {{ $json.profile.allergies.join(', ') }}
```

5. Подключите инструменты:
   - Calculate KBJU Tool → `ai_tool`
   - Search Recipes Tool → `ai_tool`
   - Generate Meal Plan Tool → `ai_tool`
   - OpenAI Chat Model → `ai_languageModel`

### 4. Настройте векторное хранилище

#### В Supabase:

1. Создайте таблицу `recipes_vector`:
```sql
CREATE TABLE recipes_vector (
  id UUID PRIMARY KEY REFERENCES recipes(id),
  embedding vector(1536),
  content TEXT,
  metadata JSONB
);
```

2. Создайте индекс:
```sql
CREATE INDEX ON recipes_vector 
USING ivfflat (embedding vector_cosine_ops)
WITH (lists = 100);
```

3. Заполните эмбеддингами (используйте OpenAI API):
```javascript
// Для каждого рецепта
const embedding = await openai.embeddings.create({
  model: "text-embedding-ada-002",
  input: recipe.title + " " + recipe.description
});

// Сохраните в recipes_vector
```

#### В n8n:

1. **Supabase Vector Store** нода:
   - Mode: `Retrieve as Tool`
   - Table: `recipes_vector`
   - Подключите OpenAI Embeddings

2. **OpenAI Embeddings**:
   - Model: `text-embedding-ada-002`

### 5. Проверка работы

1. Запустите workflow с тестовыми данными
2. Проверьте, что AI Agent вызывает инструменты:
   - В логах должно быть видно вызовы Calculate KBJU Tool
   - Затем Search Recipes Tool
   - Затем Generate Meal Plan Tool
3. Проверьте ответ агента - должен содержать план питания

## Типичные ошибки

### Ошибка: "Tool not found"
- **Причина**: Инструменты не подключены к Agent как `ai_tool`
- **Решение**: Проверьте connections - все tools должны быть подключены к Agent

### Ошибка: "Vector store not working"
- **Причина**: Неправильная таблица или нет эмбеддингов
- **Решение**: Проверьте таблицу `recipes_vector` и наличие данных

### Ошибка: "Agent не вызывает инструменты"
- **Причина**: Неправильный system message или prompt
- **Решение**: Убедитесь, что в system message четко указано использовать инструменты

### Ошибка: "Embeddings не работают"
- **Причина**: Неправильный API ключ или модель
- **Решение**: Проверьте credentials OpenAI и модель `text-embedding-ada-002`

## Оптимизация

1. **Кэширование**: Кэшируйте результаты расчета КБЖУ
2. **Batch обработка**: Обрабатывайте несколько профилей одновременно
3. **Ошибки**: Добавьте обработку ошибок в каждом инструменте
4. **Логирование**: Логируйте все вызовы инструментов для отладки

## Дополнительные инструменты

Можно добавить:
- **Search Similar Plans Tool** - поиск похожих планов
- **Validate Meal Plan Tool** - валидация плана
- **Generate Shopping List Tool** - генерация списка покупок

## Пример полного workflow

См. файл `workflow-with-ai.json` - там полная рабочая структура с правильными подключениями.

