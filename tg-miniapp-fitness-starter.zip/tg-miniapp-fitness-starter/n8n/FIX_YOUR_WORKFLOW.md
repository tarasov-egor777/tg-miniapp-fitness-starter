# Как исправить ваш текущий workflow

## Основные проблемы в вашем workflow

1. **AI Agent не вызывает инструменты** - инструменты подключены неправильно
2. **Векторный поиск не работает** - неправильная конфигурация
3. **Telegram Trigger вместо Webhook** - нет интеграции с webapp
4. **Много disabled нод** - мешают пониманию структуры

## Быстрое исправление (5 минут)

### Шаг 1: Исправьте подключение инструментов к AI Agent

В вашем workflow "Intent Extraction Agent1" должен иметь подключения:

1. **Calculate BMR and TDEE Tool** → подключите как `ai_tool` к Agent
2. **Generate Meal Plan Tool** → подключите как `ai_tool` к Agent  
3. **Search Recipes Tool** (Supabase Vector Store) → подключите как `ai_tool` к Agent
4. **OpenAI Chat Model** → подключите как `ai_languageModel` к Agent
5. **Simple Memory** → подключите как `ai_memory` к Agent

**Как проверить:**
- Откройте Agent ноду
- Посмотрите на connections справа
- Должны быть подключения от всех tools

### Шаг 2: Исправьте System Message в Agent

Замените system message на:

```
Ты - эксперт по питанию. Твоя задача - создавать персонализированные планы питания.

ВАЖНО: Ты ДОЛЖЕН использовать инструменты в следующем порядке:

1. СНАЧАЛА используй Calculate BMR and TDEE Tool для расчета калорий
   - Передай: gender, age, height, weight, activityLevel, goal
   - Получи: bmr, tdee, targetCalories, macros

2. ЗАТЕМ используй Search Recipes Tool для поиска рецептов
   - Используй targetCalories и preferences для поиска
   - Получи список подходящих рецептов

3. ПОТОМ используй Generate Meal Plan Tool для создания плана
   - Передай: targetCalories, protein, fat, carbs, recipes, preferences
   - Получи готовый план питания

4. ВСЕГДА используй РЕАЛЬНЫЕ рецепты из базы данных, не выдумывай их

5. Учитывай все аллергии и ограничения пользователя
```

### Шаг 3: Исправьте инструменты

#### A. Calculate BMR and TDEE Tool

Убедитесь, что используете `$fromAI()` для получения параметров:

```javascript
const gender = $fromAI('gender', 'User gender: male or female', 'string');
const age = $fromAI('age', 'User age in years', 'number');
// ... и т.д.
```

**НЕ используйте** `$json` или `$input` - только `$fromAI()`!

#### B. Search Recipes Tool (Vector Store)

1. Откройте ноду "Supabase Vector Store"
2. Проверьте:
   - **Mode**: `Retrieve as Tool` (НЕ `Insert`!)
   - **Table Name**: `recipes_vector` (или ваша таблица)
   - **Top K**: 5-10
3. Подключите **Embeddings OpenAI** как `ai_embedding`
4. Убедитесь, что таблица `recipes_vector` существует и заполнена

#### C. Generate Meal Plan Tool

Используйте `$fromAI()` для получения данных от агента:

```javascript
const targetCalories = $fromAI('targetCalories', 'Target daily calories', 'number');
const recipes = $fromAI('recipes', 'Recipes from database (JSON string)', 'string');
// ... и т.д.
```

### Шаг 4: Добавьте Webhook для webapp

1. Создайте новую ноду **Webhook** (вместо Telegram Trigger)
2. Настройте:
   - **HTTP Method**: POST
   - **Path**: `submit-profile`
   - **Response Mode**: Respond to Webhook
3. Подключите Webhook → Process Data → Save Profile → AI Agent

### Шаг 5: Исправьте обработку данных

Добавьте ноду Code перед AI Agent:

```javascript
// Извлекаем данные профиля
const profile = $input.item.json.profile || $input.item.json.body?.profile;

// Формируем prompt для AI Agent
const prompt = `Создай план питания для:
Пол: ${profile.sex}
Рост: ${profile.height_cm} см
Вес: ${profile.weight_kg} кг
Возраст: ${profile.age} лет
Активность: ${profile.activity_level}
Цель: ${profile.goal}
Аллергии: ${profile.allergies?.join(', ') || 'Нет'}
Ограничения: ${profile.dietary_restrictions?.join(', ') || 'Нет'}
Крупы: ${profile.grains?.join(', ') || 'Не указаны'}

Используй инструменты для расчета КБЖУ и поиска рецептов.`;

return {
  profile: profile,
  prompt: prompt
};
```

## Проверка работы

1. **Запустите workflow** с тестовыми данными
2. **Проверьте логи** - должны быть видны вызовы инструментов:
   ```
   [AI Agent] Calling Calculate BMR and TDEE Tool...
   [AI Agent] Calling Search Recipes Tool...
   [AI Agent] Calling Generate Meal Plan Tool...
   ```
3. **Проверьте ответ агента** - должен содержать план питания

## Если инструменты не вызываются

### Проблема: Agent не использует инструменты

**Решение:**
1. Проверьте system message - должно быть четко указано использовать инструменты
2. Проверьте подключения - все tools должны быть подключены как `ai_tool`
3. Убедитесь, что используете правильную модель (gpt-4o-mini или gpt-4)

### Проблема: Ошибка "Tool not found"

**Решение:**
1. Проверьте, что все tools подключены к Agent
2. Убедитесь, что tools не disabled
3. Проверьте credentials для всех нод

### Проблема: Vector Store не работает

**Решение:**
1. Проверьте таблицу `recipes_vector` в Supabase
2. Убедитесь, что есть данные с эмбеддингами
3. Проверьте подключение Embeddings к Vector Store
4. Проверьте credentials Supabase

## Альтернатива: Используйте готовый workflow

Если исправление занимает много времени, используйте готовый `workflow-with-ai.json`:

1. Импортируйте `workflow-with-ai.json`
2. Настройте credentials:
   - Supabase
   - OpenAI
   - PDF API (опционально)
3. Настройте переменные окружения
4. Готово!

## Структура правильного workflow

```
Webhook (от webapp)
  ↓
Process Data (Code)
  ↓
Save Profile (Supabase)
  ↓
AI Agent
  ├─ Calculate KBJU Tool (ai_tool)
  ├─ Search Recipes Tool (ai_tool) 
  │    └─ OpenAI Embeddings (ai_embedding)
  ├─ Generate Meal Plan Tool (ai_tool)
  ├─ OpenAI Chat Model (ai_languageModel)
  └─ Simple Memory (ai_memory)
  ↓
Extract Meal Plan (Code)
  ↓
Generate HTML
  ↓
Convert to PDF
  ↓
Save Plan (Supabase)
  ↓
Respond (Webhook)
```

## Дополнительные улучшения

1. **Добавьте обработку ошибок** в каждый инструмент
2. **Логируйте все вызовы** для отладки
3. **Кэшируйте результаты** расчета КБЖУ
4. **Добавьте валидацию** данных перед отправкой в Agent

## Пример правильного System Message

```
Ты - эксперт по питанию. Создавай персонализированные планы питания.

ПРОЦЕСС:
1. Используй Calculate KBJU Tool с параметрами пользователя
2. Используй Search Recipes Tool для поиска рецептов по калориям
3. Используй Generate Meal Plan Tool для создания плана

ПРАВИЛА:
- ВСЕГДА используй инструменты перед ответом
- Используй РЕАЛЬНЫЕ рецепты из базы данных
- Учитывай аллергии и ограничения
- Создавай разнообразное меню на неделю

ФОРМАТ ОТВЕТА:
Верни JSON с планом питания в формате:
{
  "dailyTargets": { "calories": ..., "protein": ..., "fat": ..., "carbs": ... },
  "weeklyPlan": [ { "day": "...", "meals": [...] } ]
}
```

Это должно решить проблемы с вашим workflow!

