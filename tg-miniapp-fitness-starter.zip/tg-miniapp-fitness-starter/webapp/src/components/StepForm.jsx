import React, { useState, useEffect } from 'react';
import { tg, showAlert } from '../telegram';
import './StepForm.css';

export default function StepForm({ onSubmit }) {
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({
    sex: 'Мужчина',
    height_cm: 180,
    weight_kg: 75,
    age: 30,
    activity_level: 'Сидячая работа',
    training_per_week: 3,
    goal: 'Похудеть',
    grains: [],
    allergies: [],
    dietary_restrictions: [],
    cooking_frequency: 'Каждый день',
    name: '',
    email: '',
    phone: ''
  });

  const totalSteps = 5;

  useEffect(() => {
    // Получаем данные пользователя из Telegram
    if (tg && tg.initDataUnsafe?.user) {
      const user = tg.initDataUnsafe.user;
      setForm(prev => ({
        ...prev,
        name: user.first_name || '',
        email: ''
      }));
    }
  }, []);

  function next() {
    // Валидация перед переходом к следующему шагу
    if (step === 1) {
      if (!form.height_cm || form.height_cm < 100 || form.height_cm > 250) {
        showAlert('Пожалуйста, укажите корректный рост (100-250 см)');
        return;
      }
      if (!form.weight_kg || form.weight_kg < 30 || form.weight_kg > 300) {
        showAlert('Пожалуйста, укажите корректный вес (30-300 кг)');
        return;
      }
      if (!form.age || form.age < 10 || form.age > 120) {
        showAlert('Пожалуйста, укажите корректный возраст');
        return;
      }
    }
    
    if (step === 2) {
      if (form.grains.length < 2) {
        showAlert('Выберите минимум 2 крупы для разнообразия рациона');
        return;
      }
    }

    if (step === 4) {
      if (!form.name || form.name.trim().length < 2) {
        showAlert('Пожалуйста, укажите ваше имя');
        return;
      }
      if (!form.email || !form.email.includes('@')) {
        showAlert('Пожалуйста, укажите корректный email');
        return;
      }
    }

    setStep(s => Math.min(totalSteps, s + 1));
  }

  function prev() {
    setStep(s => Math.max(1, s - 1));
  }

  function update(key, value) {
    setForm(f => ({ ...f, [key]: value }));
  }

  function toggleArray(key, value) {
    setForm(f => {
      const arr = f[key] || [];
      const index = arr.indexOf(value);
      if (index > -1) {
        return { ...f, [key]: arr.filter(item => item !== value) };
      } else {
        return { ...f, [key]: [...arr, value] };
      }
    });
  }

  function handleSubmit() {
    onSubmit(form);
  }

  const progress = (step / totalSteps) * 100;

  return (
    <div className="step-form">
      <div className="progress-bar">
        <div className="progress-fill" style={{ width: `${progress}%` }}></div>
      </div>

      <div className="step-content">
        {/* Шаг 1: Основные данные */}
        {step === 1 && (
          <div className="step">
            <h2>Основные данные</h2>
            <p className="step-description">Укажите ваши физические параметры</p>
            
            <div className="form-group">
              <label>Пол</label>
              <select 
                value={form.sex} 
                onChange={e => update('sex', e.target.value)}
              >
                <option value="Мужчина">Мужчина</option>
                <option value="Женщина">Женщина</option>
              </select>
            </div>

            <div className="form-group">
              <label>Рост (см)</label>
              <input 
                type="number" 
                min="100" 
                max="250"
                value={form.height_cm} 
                onChange={e => update('height_cm', +e.target.value)} 
                placeholder="180"
              />
            </div>

            <div className="form-group">
              <label>Вес (кг)</label>
              <input 
                type="number" 
                min="30" 
                max="300"
                value={form.weight_kg} 
                onChange={e => update('weight_kg', +e.target.value)} 
                placeholder="75"
              />
            </div>

            <div className="form-group">
              <label>Возраст</label>
              <input 
                type="number" 
                min="10" 
                max="120"
                value={form.age} 
                onChange={e => update('age', +e.target.value)} 
                placeholder="30"
              />
            </div>
          </div>
        )}

        {/* Шаг 2: Цель и предпочтения */}
        {step === 2 && (
          <div className="step">
            <h2>Цель и активность</h2>
            <p className="step-description">Что вы хотите достичь?</p>
            
            <div className="form-group">
              <label>Цель</label>
              <select 
                value={form.goal} 
                onChange={e => update('goal', e.target.value)}
              >
                <option value="Похудеть">Похудеть</option>
                <option value="Набрать массу">Набрать массу</option>
                <option value="Поддержание веса">Поддержание веса</option>
                <option value="Сушка">Сушка</option>
              </select>
            </div>

            <div className="form-group">
              <label>Уровень активности</label>
              <select 
                value={form.activity_level} 
                onChange={e => update('activity_level', e.target.value)}
              >
                <option value="Сидячая работа">Сидячая работа</option>
                <option value="Небольшая активность">Небольшая активность (1-3 тренировки/нед)</option>
                <option value="Умеренная">Умеренная активность (3-5 тренировок/нед)</option>
                <option value="Высокая">Высокая активность (6-7 тренировок/нед)</option>
              </select>
            </div>

            <div className="form-group">
              <label>Тренировок в неделю</label>
              <input 
                type="number" 
                min="0" 
                max="14"
                value={form.training_per_week} 
                onChange={e => update('training_per_week', +e.target.value)} 
              />
            </div>

            <div className="form-group">
              <label>Крупы (выберите минимум 2)</label>
              <div className="checkbox-group">
                {['Гречка', 'Рис белый', 'Рис бурый', 'Овсянка', 'Пшенка', 'Булгур', 'Киноа'].map(grain => (
                  <label key={grain} className="checkbox-label">
                    <input 
                      type="checkbox" 
                      checked={form.grains.includes(grain)} 
                      onChange={() => toggleArray('grains', grain)} 
                    />
                    <span>{grain}</span>
                  </label>
                ))}
              </div>
              {form.grains.length > 0 && (
                <p className="hint">Выбрано: {form.grains.length}</p>
              )}
            </div>
          </div>
        )}

        {/* Шаг 3: Аллергии и ограничения */}
        {step === 3 && (
          <div className="step">
            <h2>Аллергии и ограничения</h2>
            <p className="step-description">Укажите продукты, которые нужно исключить</p>
            
            <div className="form-group">
              <label>Аллергии</label>
              <div className="checkbox-group">
                {['Молочные продукты', 'Яйца', 'Орехи', 'Рыба', 'Морепродукты', 'Глютен', 'Соя'].map(item => (
                  <label key={item} className="checkbox-label">
                    <input 
                      type="checkbox" 
                      checked={form.allergies.includes(item)} 
                      onChange={() => toggleArray('allergies', item)} 
                    />
                    <span>{item}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="form-group">
              <label>Диетические ограничения</label>
              <div className="checkbox-group">
                {['Вегетарианство', 'Веганство', 'Кето', 'Палео', 'Без сахара'].map(item => (
                  <label key={item} className="checkbox-label">
                    <input 
                      type="checkbox" 
                      checked={form.dietary_restrictions.includes(item)} 
                      onChange={() => toggleArray('dietary_restrictions', item)} 
                    />
                    <span>{item}</span>
                  </label>
                ))}
              </div>
            </div>

            <div className="form-group">
              <label>Как часто готовите?</label>
              <select 
                value={form.cooking_frequency} 
                onChange={e => update('cooking_frequency', e.target.value)}
              >
                <option value="Каждый день">Каждый день</option>
                <option value="Через день">Через день</option>
                <option value="2-3 раза в неделю">2-3 раза в неделю</option>
                <option value="Минимум готовки">Минимум готовки</option>
              </select>
            </div>
          </div>
        )}

        {/* Шаг 4: Контакты */}
        {step === 4 && (
          <div className="step">
            <h2>Контакты</h2>
            <p className="step-description">Как с вами связаться?</p>
            
            <div className="form-group">
              <label>Имя *</label>
              <input 
                type="text" 
                value={form.name} 
                onChange={e => update('name', e.target.value)} 
                placeholder="Ваше имя"
                required
              />
            </div>

            <div className="form-group">
              <label>Email *</label>
              <input 
                type="email" 
                value={form.email} 
                onChange={e => update('email', e.target.value)} 
                placeholder="your@email.com"
                required
              />
            </div>

            <div className="form-group">
              <label>Телефон (опционально)</label>
              <input 
                type="tel" 
                value={form.phone} 
                onChange={e => update('phone', e.target.value)} 
                placeholder="+7 (999) 123-45-67"
              />
            </div>
          </div>
        )}

        {/* Шаг 5: Подтверждение */}
        {step === 5 && (
          <div className="step">
            <h2>Проверьте данные</h2>
            <div className="summary">
              <div className="summary-item">
                <strong>Пол:</strong> {form.sex}
              </div>
              <div className="summary-item">
                <strong>Параметры:</strong> {form.height_cm} см, {form.weight_kg} кг, {form.age} лет
              </div>
              <div className="summary-item">
                <strong>Цель:</strong> {form.goal}
              </div>
              <div className="summary-item">
                <strong>Активность:</strong> {form.activity_level} ({form.training_per_week} тренировок/нед)
              </div>
              <div className="summary-item">
                <strong>Крупы:</strong> {form.grains.join(', ')}
              </div>
              {form.allergies.length > 0 && (
                <div className="summary-item">
                  <strong>Аллергии:</strong> {form.allergies.join(', ')}
                </div>
              )}
              <div className="summary-item">
                <strong>Контакты:</strong> {form.name}, {form.email}
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="step-actions">
        {step > 1 && (
          <button className="btn-secondary" onClick={prev}>
            Назад
          </button>
        )}
        {step < totalSteps ? (
          <button className="btn-primary" onClick={next}>
            Далее
          </button>
        ) : (
          <button className="btn-primary" onClick={handleSubmit}>
            Отправить анкету
          </button>
        )}
      </div>
    </div>
  );
}



