import React, { useEffect, useState } from 'react';
import StepForm from './components/StepForm';
import { initTelegram, sendToWebhook, showAlert, getUserData } from './telegram';
import { initPayments, showInvoice, sendPaymentConfirmation } from './payment';
import './App.css';

export default function App() {
  const [profileSubmitted, setProfileSubmitted] = useState(false);
  const [submittedProfile, setSubmittedProfile] = useState(null);

  useEffect(() => {
    // Инициализация Telegram Web App
    initTelegram();
    initPayments();
  }, []);

  async function handleSubmit(formData) {
    try {
      // Получаем данные пользователя из Telegram
      const userData = getUserData();
      
      // Формируем payload для отправки на n8n webhook
      const payload = {
        type: 'submit_profile',
        timestamp: new Date().toISOString(),
        user: userData ? {
          id: userData.id,
          username: userData.username,
          first_name: userData.first_name,
          last_name: userData.last_name
        } : null,
        profile: {
          sex: formData.sex,
          height_cm: formData.height_cm,
          weight_kg: formData.weight_kg,
          age: formData.age,
          activity_level: formData.activity_level,
          training_per_week: formData.training_per_week,
          goal: formData.goal,
          grains: formData.grains,
          allergies: formData.allergies,
          dietary_restrictions: formData.dietary_restrictions,
          cooking_frequency: formData.cooking_frequency
        },
        contact: {
          name: formData.name,
          email: formData.email,
          phone: formData.phone
        }
      };

      // Отправляем данные напрямую на n8n webhook
      const result = await sendToWebhook(payload);
      
      if (result.success) {
        setProfileSubmitted(true);
        setSubmittedProfile({ ...payload, profileId: result.data?.profile_id });
        showAlert('Анкета отправлена! Теперь нужно оплатить план питания.');
        
        // Показываем кнопку оплаты
        await handlePayment();
      } else {
        showAlert(`Ошибка отправки: ${result.error || 'Неизвестная ошибка'}. Пожалуйста, попробуйте позже.`);
      }
    } catch (error) {
      console.error('Ошибка отправки анкеты:', error);
      showAlert('Произошла ошибка. Пожалуйста, попробуйте позже.');
    }
  }

  async function handlePayment() {
    try {
      // Получаем цену из env или используем дефолтную
      const price = parseInt(import.meta.env.VITE_MEAL_PLAN_PRICE || '1990');
      
      // Создаем инвойс
      const invoice = {
        title: 'Персональный план питания',
        description: 'Индивидуальный план питания с расчетом КБЖУ, рецептами и рекомендациями',
        payload: JSON.stringify({
          type: 'meal_plan_payment',
          profileId: submittedProfile?.profileId,
          timestamp: new Date().toISOString()
        }),
        currency: 'RUB',
        prices: [
          {
            label: 'Персональный план питания',
            amount: price * 100 // В копейках
          }
        ]
      };

      // Показываем инвойс
      const paymentResult = await showInvoice(invoice);
      
      if (paymentResult.success) {
        // Отправляем подтверждение оплаты на webhook
        const confirmResult = await sendPaymentConfirmation({
          profileId: submittedProfile?.profileId,
          amount: price,
          currency: 'RUB',
          paymentMethod: 'telegram',
          status: 'paid'
        });

        if (confirmResult.success) {
          showAlert('Оплата успешна! План питания будет сгенерирован и отправлен вам в течение нескольких минут.');
        } else {
          showAlert('Оплата прошла, но произошла ошибка при обработке. Пожалуйста, свяжитесь с поддержкой.');
        }
      }
    } catch (error) {
      console.error('Ошибка оплаты:', error);
      if (error.message !== 'Payment cancelled') {
        showAlert(`Ошибка оплаты: ${error.message}`);
      }
    }
  }

  if (profileSubmitted) {
    return (
      <div className="app" style={{ padding: '20px', textAlign: 'center' }}>
        <h2>Анкета отправлена! ✅</h2>
        <p>Теперь нужно оплатить план питания</p>
        <button 
          onClick={handlePayment}
          style={{
            padding: '15px 30px',
            fontSize: '18px',
            backgroundColor: '#3390ec',
            color: 'white',
            border: 'none',
            borderRadius: '8px',
            cursor: 'pointer',
            marginTop: '20px'
          }}
        >
          Оплатить план питания
        </button>
      </div>
    );
  }

  return (
    <div className="app">
      <StepForm onSubmit={handleSubmit} />
    </div>
  );
}



