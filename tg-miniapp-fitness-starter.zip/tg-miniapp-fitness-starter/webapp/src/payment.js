/**
 * Интеграция с Telegram Payments
 */

export const tg = window.Telegram?.WebApp || null;

/**
 * Инициализация платежей
 */
export function initPayments() {
  if (!tg) {
    console.warn('Telegram WebApp API не доступен');
    return false;
  }

  // Включаем платежи
  if (tg.MainButton) {
    tg.MainButton.setText('Оплатить');
    tg.MainButton.show();
  }

  return true;
}

/**
 * Показать инвойс для оплаты через Telegram Payments
 */
export function showInvoice(invoiceData) {
  if (!tg || !tg.openInvoice) {
    console.error('Telegram Payments не доступны');
    return Promise.reject(new Error('Payments not available'));
  }

  return new Promise((resolve, reject) => {
    tg.openInvoice(invoiceData, (status) => {
      if (status === 'paid') {
        resolve({ success: true, status: 'paid' });
      } else if (status === 'failed') {
        reject(new Error('Payment failed'));
      } else if (status === 'cancelled') {
        reject(new Error('Payment cancelled'));
      } else {
        reject(new Error(`Unknown status: ${status}`));
      }
    });
  });
}

/**
 * Создать инвойс для оплаты плана питания
 */
export function createMealPlanInvoice(amount, currency = 'RUB', description = 'Персональный план питания') {
  return {
    title: 'План питания',
    description: description,
    payload: JSON.stringify({
      type: 'meal_plan_payment',
      timestamp: new Date().toISOString()
    }),
    provider_token: '', // Заполняется на сервере или через BotFather
    currency: currency,
    prices: [
      {
        label: 'Персональный план питания',
        amount: amount * 100 // В копейках/центах
      }
    ],
    need_name: false,
    need_phone_number: false,
    need_email: false,
    need_shipping_address: false,
    send_phone_number_to_provider: false,
    send_email_to_provider: false,
    is_flexible: false
  };
}

/**
 * Отправить данные об оплате на webhook
 */
export async function sendPaymentConfirmation(paymentData) {
  const webhookUrl = import.meta.env.VITE_WEBHOOK_URL;
  
  if (!webhookUrl) {
    console.error('VITE_WEBHOOK_URL не настроен');
    return { success: false, error: 'Webhook URL not configured' };
  }

  try {
    const response = await fetch(`${webhookUrl}/payment-confirm`, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        type: 'payment_confirmation',
        ...paymentData
      })
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const result = await response.json();
    return { success: true, data: result };
  } catch (error) {
    console.error('Ошибка отправки подтверждения оплаты:', error);
    return { success: false, error: error.message };
  }
}

