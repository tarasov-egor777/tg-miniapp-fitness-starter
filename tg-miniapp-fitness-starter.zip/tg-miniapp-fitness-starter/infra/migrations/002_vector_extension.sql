-- Миграция 002: Расширение для векторного поиска рецептов
-- Требует установки расширения pgvector в Supabase
-- Выполните: CREATE EXTENSION IF NOT EXISTS vector;

-- Таблица для хранения эмбеддингов рецептов (для семантического поиска)
create table if not exists recipes_vector (
  id uuid primary key references recipes(id) on delete cascade,
  embedding vector(1536), -- Размерность для OpenAI text-embedding-ada-002
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Индекс для векторного поиска (HNSW для быстрого поиска)
-- Раскомментируйте после установки pgvector:
-- create index if not exists idx_recipes_vector_embedding on recipes_vector 
--   using hnsw (embedding vector_cosine_ops);

-- Функция для поиска похожих рецептов по эмбеддингу
create or replace function search_similar_recipes(
  query_embedding vector(1536),
  match_threshold float default 0.7,
  match_count int default 10
)
returns table (
  id uuid,
  title text,
  description text,
  similarity float
)
language plpgsql
as $$
begin
  return query
  select
    r.id,
    r.title,
    r.description,
    1 - (rv.embedding <=> query_embedding) as similarity
  from recipes_vector rv
  join recipes r on r.id = rv.id
  where 1 - (rv.embedding <=> query_embedding) > match_threshold
  order by rv.embedding <=> query_embedding
  limit match_count;
end;
$$;

comment on table recipes_vector is 'Векторные представления рецептов для семантического поиска';
comment on function search_similar_recipes is 'Поиск похожих рецептов по векторному сходству';



