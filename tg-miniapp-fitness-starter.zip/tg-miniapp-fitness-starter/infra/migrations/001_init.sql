-- Миграция 001: Базовая структура БД для Telegram Mini App Fitness
-- Выполните эту миграцию в SQL Editor Supabase

-- Включение расширений
create extension if not exists "pgcrypto";
create extension if not exists "uuid-ossp";

-- Таблица пользователей (из Telegram)
create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  telegram_id bigint unique,
  username text,
  first_name text,
  last_name text,
  email text,
  phone text,
  role text default 'client' check (role in ('client', 'trainer', 'admin')),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Индекс для быстрого поиска по telegram_id
create index if not exists idx_users_telegram_id on users(telegram_id);

-- Таблица профилей (анкеты пользователей)
create table if not exists profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references users(id) on delete cascade,
  sex text check (sex in ('Мужчина', 'Женщина')),
  height_cm integer,
  weight_kg numeric(5,2),
  age integer,
  activity_level text check (activity_level in ('Сидячая работа', 'Небольшая активность', 'Умеренная', 'Высокая')),
  training_per_week integer default 0,
  goal text check (goal in ('Похудеть', 'Набрать массу', 'Поддержание веса', 'Сушка')),
  preferences jsonb default '{}'::jsonb, -- {grains: [], allergies: [], dietary_restrictions: [], cooking_frequency: ''}
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Индекс для поиска профилей пользователя
create index if not exists idx_profiles_user_id on profiles(user_id);

-- Таблица рецептов
create table if not exists recipes (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  ingredients jsonb not null default '[]'::jsonb, -- [{name: "Куриная грудка", amount: 200, unit: "г"}]
  instructions text[] default array[]::text[],
  kcal_per_100g numeric(6,2),
  protein_per_100g numeric(6,2),
  fats_per_100g numeric(6,2),
  carbs_per_100g numeric(6,2),
  tags text[] default array[]::text[], -- ['завтрак', 'обед', 'ужин', 'перекус', 'вегетарианский']
  cooking_time_minutes integer,
  difficulty text check (difficulty in ('Легко', 'Средне', 'Сложно')),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

-- Индекс для поиска по тегам
create index if not exists idx_recipes_tags on recipes using gin(tags);

-- Таблица планов питания
create table if not exists plans (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid references profiles(id) on delete cascade,
  trainer_id uuid references users(id) on delete set null,
  title text default 'Индивидуальный план питания',
  total_kcal numeric(6,2),
  macros jsonb default '{}'::jsonb, -- {protein_g: 150, fats_g: 65, carbs_g: 200}
  meals jsonb default '[]'::jsonb, -- [{day: 1, meal: "завтрак", recipe_id: uuid, portion_g: 250}]
  status text default 'draft' check (status in ('draft', 'active', 'completed', 'archived')),
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  expires_at timestamptz
);

-- Индекс для поиска планов по профилю
create index if not exists idx_plans_profile_id on plans(profile_id);
create index if not exists idx_plans_status on plans(status);

-- Таблица версий планов (для истории изменений)
create table if not exists plans_versions (
  id uuid primary key default gen_random_uuid(),
  plan_id uuid references plans(id) on delete cascade,
  version_number integer not null,
  payload jsonb not null, -- Полный снимок плана на момент версии
  changelog text,
  created_by uuid references users(id),
  created_at timestamptz default now(),
  unique(plan_id, version_number)
);

-- Индекс для поиска версий плана
create index if not exists idx_plans_versions_plan_id on plans_versions(plan_id);

-- Таблица платежей (для отслеживания оплаты планов)
create table if not exists payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references users(id) on delete set null,
  plan_id uuid references plans(id) on delete set null,
  amount numeric(10,2) not null,
  currency text default 'RUB',
  payment_method text, -- 'telegram', 'stripe', etc.
  payment_provider_id text, -- ID транзакции от провайдера
  status text default 'pending' check (status in ('pending', 'completed', 'failed', 'refunded')),
  metadata jsonb default '{}'::jsonb,
  created_at timestamptz default now(),
  completed_at timestamptz
);

-- Индекс для поиска платежей пользователя
create index if not exists idx_payments_user_id on payments(user_id);
create index if not exists idx_payments_status on payments(status);

-- Функция для автоматического обновления updated_at
create or replace function update_updated_at_column()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

-- Триггеры для автоматического обновления updated_at
create trigger update_users_updated_at before update on users
  for each row execute function update_updated_at_column();

create trigger update_profiles_updated_at before update on profiles
  for each row execute function update_updated_at_column();

create trigger update_recipes_updated_at before update on recipes
  for each row execute function update_updated_at_column();

create trigger update_plans_updated_at before update on plans
  for each row execute function update_updated_at_column();

-- RLS (Row Level Security) политики (базовые)
alter table users enable row level security;
alter table profiles enable row level security;
alter table recipes enable row level security;
alter table plans enable row level security;
alter table payments enable row level security;

-- Политика: пользователи могут видеть только свои данные
create policy "Users can view own data" on users
  for select using (auth.uid()::text = id::text);

create policy "Users can view own profiles" on profiles
  for select using (auth.uid()::text = user_id::text);

create policy "Users can view own plans" on plans
  for select using (auth.uid()::text = profile_id::text);

-- Политика: все могут читать рецепты (публичные)
create policy "Recipes are public" on recipes
  for select using (true);

-- Комментарии к таблицам
comment on table users is 'Пользователи из Telegram';
comment on table profiles is 'Профили и анкеты пользователей';
comment on table recipes is 'База рецептов блюд';
comment on table plans is 'Индивидуальные планы питания';
comment on table plans_versions is 'История версий планов';
comment on table payments is 'Платежи за планы питания';



