# Полная схема интеграции всех компонентов

## 📊 Диаграмма потока данных

```
┌─────────────────────────────────────────────────────────────┐
│                    TELEGRAM MINI APP                        │
│  (webapp/src/App.jsx + StepForm.jsx)                       │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        │ POST /submit-profile
                        │ { profile, user, contact }
                        ▼
┌─────────────────────────────────────────────────────────────┐
│                    n8n WEBHOOK                              │
│  /webhook/submit-profile                                    │
│  (n8n/workflow-complete.json)                              │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        │ Process Profile Data
                        ▼
┌─────────────────────────────────────────────────────────────┐
│                    SUPABASE                                 │
│  Table: profiles                                            │
│  - Сохранение анкеты                                       │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        │ Return: { profile_id }
                        ▼
┌─────────────────────────────────────────────────────────────┐
│                    TELEGRAM MINI APP                        │
│  (webapp/src/payment.js)                                   │
│  - Показ кнопки оплаты                                      │
│  - Telegram.WebApp.openInvoice()                           │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        │ Telegram Payments
                        │ (paid/failed/cancelled)
                        ▼
┌─────────────────────────────────────────────────────────────┐
│                    TELEGRAM MINI APP                        │
│  (webapp/src/payment.js)                                   │
│  - Обработка результата оплаты                              │
│  - POST /payment-confirm                                    │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        │ POST /payment-confirm
                        │ { profileId, amount, status: 'paid' }
                        ▼
┌─────────────────────────────────────────────────────────────┐
│                    n8n WEBHOOK                              │
│  /webhook/payment-confirm                                   │
│  (n8n/workflow-complete.json)                              │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        │ Save Payment → Get Profile
                        ▼
┌─────────────────────────────────────────────────────────────┐
│                    SUPABASE                                 │
│  Table: payments                                            │
│  Table: profiles (получение)                                │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        │ Запуск генерации плана
                        ▼
┌─────────────────────────────────────────────────────────────┐
│                    AI AGENT                                 │
│  (n8n/workflow-with-ai.json)                                │
│  - Calculate KBJU Tool                                      │
│  - Search Recipes Tool (Vector Store)                       │
│  - Generate Meal Plan Tool                                  │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        │ Генерация HTML → PDF
                        ▼
┌─────────────────────────────────────────────────────────────┐
│                    PDF GENERATOR                            │
│  (html2pdf.app или свой сервис)                            │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        │ Сохранение плана
                        ▼
┌─────────────────────────────────────────────────────────────┐
│                    SUPABASE                                 │
│  Table: plans                                               │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        │ Отправка PDF
                        ▼
┌─────────────────────────────────────────────────────────────┐
│                    TELEGRAM BOT API                         │
│  sendDocument                                               │
│  (через n8n HTTP Request)                                  │
└───────────────────────┬─────────────────────────────────────┘
                        │
                        │ PDF файл
                        ▼
┌─────────────────────────────────────────────────────────────┐
│                    ПОЛЬЗОВАТЕЛЬ                             │
│  Получает план питания в Telegram                           │
└─────────────────────────────────────────────────────────────┘
```

## 🔄 Детальный поток данных

### Этап 1: Отправка анкеты

**Webapp → n8n**

**Файл:** `webapp/src/App.jsx`

```javascript
const payload = {
  type: 'submit_profile',
  user: { id: 123456789, ... },
  profile: { sex: 'Мужчина', height_cm: 180, ... },
  contact: { name: '...', email: '...' }
};

await sendToWebhook(payload); // → POST /webhook/submit-profile
```

**n8n обрабатывает:**
1. `Process Profile` - извлекает данные
2. `Save Profile` - сохраняет в Supabase `profiles`
3. `Respond Profile` - возвращает `{ profile_id: '...' }`

**Webapp получает:**
```json
{
  "success": true,
  "profile_id": "uuid-here",
  "message": "Профиль сохранен. Ожидайте оплаты."
}
```

### Этап 2: Оплата

**Webapp → Telegram Payments**

**Файл:** `webapp/src/payment.js`

```javascript
const invoice = {
  title: 'Персональный план питания',
  currency: 'RUB',
  prices: [{ label: '...', amount: 199000 }],
  payload: JSON.stringify({ type: 'meal_plan_payment', profileId: '...' })
};

await showInvoice(invoice); // Telegram.WebApp.openInvoice()
```

**Telegram обрабатывает оплату:**
- Пользователь оплачивает через Telegram Payments
- Возвращает статус: `paid` / `failed` / `cancelled`

**Webapp обрабатывает результат:**
```javascript
if (status === 'paid') {
  await sendPaymentConfirmation({
    profileId: '...',
    amount: 1990,
    status: 'paid'
  }); // → POST /webhook/payment-confirm
}
```

### Этап 3: Подтверждение оплаты и генерация

**Webapp → n8n**

**n8n обрабатывает:**
1. `Process Payment` - извлекает данные оплаты
2. `Save Payment` - сохраняет в Supabase `payments`
3. `Get Profile` - получает профиль по `profileId`
4. **Запускает AI Agent** для генерации плана

**AI Agent генерирует план:**
1. Вызывает `Calculate KBJU Tool` → получает калории и макронутриенты
2. Вызывает `Search Recipes Tool` → находит рецепты из базы
3. Вызывает `Generate Meal Plan Tool` → создает план питания

### Этап 4: Генерация PDF

**n8n → PDF Generator**

1. `Extract Meal Plan` - извлекает план из ответа AI
2. `Generate HTML` - создает HTML шаблон
3. `Convert to PDF` - отправляет HTML в PDF сервис
4. `Save Plan` - сохраняет план в Supabase `plans`

### Этап 5: Отправка пользователю

**n8n → Telegram Bot API**

```javascript
POST https://api.telegram.org/bot{TOKEN}/sendDocument
{
  "chat_id": 123456789,
  "document": <PDF binary>,
  "caption": "Ваш план питания готов! 🎉"
}
```

## 📁 Файлы и их роль

### Webapp

| Файл | Роль |
|------|------|
| `src/App.jsx` | Главный компонент, отправка анкеты |
| `src/components/StepForm.jsx` | Мультишаговая форма анкеты |
| `src/telegram.js` | Интеграция с Telegram.WebApp API |
| `src/payment.js` | **НОВОЕ** - Обработка оплаты через Telegram Payments |

### n8n Workflows

| Файл | Роль |
|------|------|
| `workflow-complete.json` | **НОВОЕ** - Полный workflow с двумя webhook'ами |
| `workflow-with-ai.json` | Workflow с AI Agent для генерации плана |
| `workflow-minimal.json` | Минимальный workflow для тестирования |

### Backend/API

| Файл | Роль |
|------|------|
| `api/src/calculator.ts` | Расчет КБЖУ (используется в AI Tool) |
| `api/src/index.ts` | HTTP endpoint (опционально) |

### База данных

| Таблица | Роль |
|---------|------|
| `users` | Пользователи из Telegram |
| `profiles` | Анкеты пользователей |
| `payments` | Платежи за планы |
| `plans` | Сгенерированные планы питания |
| `recipes` | База рецептов |
| `recipes_vector` | Векторные эмбеддинги рецептов |

## 🔗 Связи между компонентами

### 1. Webapp ↔ n8n

**Webhook URL:** `VITE_WEBHOOK_URL`

- `/submit-profile` - отправка анкеты
- `/payment-confirm` - подтверждение оплаты

### 2. n8n ↔ Supabase

**Credentials:** Supabase API (Service Role)

- Запись профилей
- Запись платежей
- Запись планов
- Чтение профилей
- Векторный поиск рецептов

### 3. n8n ↔ OpenAI

**Credentials:** OpenAI API

- AI Agent (gpt-4o-mini)
- Embeddings (text-embedding-ada-002)

### 4. n8n ↔ Telegram Bot API

**Credentials:** Telegram Bot Token

- Отправка PDF через `sendDocument`

### 5. Webapp ↔ Telegram Payments

**API:** `Telegram.WebApp.openInvoice()`

- Показ инвойса
- Обработка результата оплаты

## ✅ Чеклист полной интеграции

- [x] Webapp отправляет анкету → n8n webhook
- [x] n8n сохраняет профиль → Supabase
- [x] Webapp получает profile_id
- [x] Webapp показывает инвойс → Telegram Payments
- [x] Webapp обрабатывает оплату
- [x] Webapp отправляет подтверждение → n8n webhook
- [x] n8n сохраняет платеж → Supabase
- [x] n8n получает профиль → Supabase
- [x] n8n запускает AI Agent
- [x] AI Agent генерирует план
- [x] n8n создает PDF
- [x] n8n сохраняет план → Supabase
- [x] n8n отправляет PDF → Telegram Bot API
- [ ] Настроить провайдера платежей в BotFather
- [ ] Добавить обработку ошибок на всех этапах
- [ ] Добавить логирование
- [ ] Добавить уведомления пользователю

## 🚀 Быстрый старт

1. **Настройте webapp:**
   ```env
   VITE_WEBHOOK_URL=https://your-n8n.com/webhook
   VITE_MEAL_PLAN_PRICE=1990
   ```

2. **Импортируйте workflow:**
   - `workflow-complete.json` в n8n
   - Добавьте AI Agent часть из `workflow-with-ai.json`

3. **Настройте credentials в n8n:**
   - Supabase
   - OpenAI
   - Telegram Bot Token

4. **Настройте BotFather:**
   - Включите Payments
   - Настройте провайдера

5. **Протестируйте:**
   - Отправьте анкету
   - Оплатите (тестовый режим)
   - Проверьте генерацию плана
   - Проверьте отправку PDF

Все компоненты связаны! 🎉

