/**
 * Telegram Web App API интеграция
 */

export const tg = window.Telegram?.WebApp || null;

/**
 * Инициализация Telegram Web App
 */
export function initTelegram() {
  if (!tg) {
    console.warn('Telegram WebApp API не доступен');
    return false;
  }

  // Расширяем приложение на весь экран
  tg.expand();
  
  // Включаем закрывающую кнопку
  tg.enableClosingConfirmation();
  
  // Настраиваем цветовую схему
  tg.setHeaderColor('#ffffff');
  tg.setBackgroundColor('#ffffff');
  
  return true;
}

/**
 * Отправка данных на n8n webhook напрямую
 * Это основной способ отправки данных из Mini App
 */
export async function sendToWebhook(payload) {
  const webhookUrl = import.meta.env.VITE_WEBHOOK_URL;
  
  if (!webhookUrl) {
    console.error('VITE_WEBHOOK_URL не настроен в .env');
    return false;
  }

  try {
    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const result = await response.json();
    return { success: true, data: result };
  } catch (error) {
    console.error('Ошибка отправки на webhook:', error);
    return { success: false, error: error.message };
  }
}

/**
 * Отправка данных боту через Telegram.WebApp.sendData()
 * Используется, если бот настроен на получение данных через sendData
 */
export function sendDataToBot(payload) {
  if (tg && tg.sendData) {
    tg.sendData(JSON.stringify(payload));
    return true;
  }
  return false;
}

/**
 * Показать уведомление пользователю
 */
export function showAlert(message) {
  if (tg && tg.showAlert) {
    tg.showAlert(message);
  } else {
    alert(message);
  }
}

/**
 * Показать подтверждение
 */
export function showConfirm(message, callback) {
  if (tg && tg.showConfirm) {
    tg.showConfirm(message, callback);
  } else {
    if (confirm(message)) {
      callback(true);
    }
  }
}

/**
 * Получить данные пользователя из Telegram
 */
export function getUserData() {
  if (tg && tg.initDataUnsafe) {
    return tg.initDataUnsafe.user || null;
  }
  return null;
}

/**
 * Получить initData для валидации на сервере
 */
export function getInitData() {
  if (tg && tg.initData) {
    return tg.initData;
  }
  return null;
}



