# Инструкция по экспорту проекта из Cursor

## Способ 1: Копирование файлов вручную (самый простой)

1. **Откройте Finder** (на Mac) или **Проводник** (на Windows)
2. **Перейдите в папку проекта**:
   ```
   /Users/tarasovegor/tg-miniapp-fitness-starter
   ```
3. **Скопируйте всю папку** в нужное место (например, на рабочий стол или в другую директорию)
4. Готово! Теперь можете открыть проект в любом редакторе или терминале

## Способ 2: Использование терминала (рекомендуется)

### На Mac/Linux:

```bash
# Перейдите в родительскую директорию
cd /Users/tarasovegor

# Скопируйте проект
cp -r tg-miniapp-fitness-starter ~/Desktop/tg-miniapp-fitness-starter

# Или создайте архив
tar -czf tg-miniapp-fitness-starter.tar.gz tg-miniapp-fitness-starter
```

### На Windows (PowerShell):

```powershell
# Скопируйте проект
Copy-Item -Path "C:\Users\tarasovegor\tg-miniapp-fitness-starter" -Destination "C:\Users\tarasovegor\Desktop\tg-miniapp-fitness-starter" -Recurse

# Или создайте ZIP архив
Compress-Archive -Path "C:\Users\tarasovegor\tg-miniapp-fitness-starter" -DestinationPath "C:\Users\tarasovegor\Desktop\tg-miniapp-fitness-starter.zip"
```

## Способ 3: Использование Git (для версионирования)

Если у вас установлен Git:

```bash
cd /Users/tarasovegor/tg-miniapp-fitness-starter

# Инициализируйте репозиторий
git init

# Добавьте все файлы
git add .

# Создайте первый коммит
git commit -m "Initial commit: Telegram Mini App Fitness Starter"

# (Опционально) Создайте репозиторий на GitHub и подключите:
# git remote add origin https://github.com/yourusername/tg-miniapp-fitness-starter.git
# git push -u origin main
```

## Способ 4: Экспорт через Cursor (если доступно)

1. В Cursor откройте **File → Export** (если есть такая опция)
2. Или используйте **File → Save As** для отдельных файлов
3. Или просто скопируйте файлы через Finder/Проводник

## Что делать после экспорта

1. **Откройте проект в терминале**:
   ```bash
   cd /path/to/tg-miniapp-fitness-starter
   ```

2. **Установите зависимости**:
   ```bash
   # Frontend
   cd webapp
   npm install
   
   # Backend
   cd ../api
   npm install
   ```

3. **Настройте переменные окружения**:
   - Создайте `webapp/.env` (см. `QUICKSTART.md`)
   - Создайте `api/.env` (см. `QUICKSTART.md`)

4. **Запустите проект**:
   ```bash
   # Frontend
   cd webapp
   npm run dev
   
   # Backend тесты
   cd ../api
   npm test
   ```

## Структура файлов для проверки

Убедитесь, что у вас есть все эти файлы:

```
tg-miniapp-fitness-starter/
├── README.md
├── QUICKSTART.md
├── PROJECT_STRUCTURE.md
├── EXPORT_INSTRUCTIONS.md (этот файл)
├── .gitignore
├── webapp/
│   ├── package.json
│   ├── vite.config.js
│   ├── index.html
│   └── src/
│       ├── main.jsx
│       ├── App.jsx
│       ├── App.css
│       ├── index.css
│       ├── telegram.js
│       └── components/
│           ├── StepForm.jsx
│           └── StepForm.css
├── api/
│   ├── package.json
│   ├── tsconfig.json
│   └── src/
│       ├── calculator.ts
│       └── index.ts
│   └── test/
│       └── calculator.test.ts
├── infra/
│   └── migrations/
│       ├── 001_init.sql
│       └── 002_vector_extension.sql
└── n8n/
    ├── workflow.json
    └── README.md
```

## Быстрая команда для копирования (Mac/Linux)

Выполните в терминале:

```bash
# Создать копию на рабочем столе
cp -r /Users/tarasovegor/tg-miniapp-fitness-starter ~/Desktop/tg-miniapp-fitness-starter

# Перейти в скопированный проект
cd ~/Desktop/tg-miniapp-fitness-starter

# Установить зависимости
cd webapp && npm install && cd ../api && npm install
```

## Проблемы?

Если файлы не копируются:
1. Проверьте права доступа к папке
2. Убедитесь, что папка не заблокирована
3. Попробуйте скопировать через Finder/Проводник вручную

Если npm install не работает:
1. Убедитесь, что Node.js установлен: `node --version`
2. Убедитесь, что npm установлен: `npm --version`
3. Если нет - установите Node.js с [nodejs.org](https://nodejs.org)

