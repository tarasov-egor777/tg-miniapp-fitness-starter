/**
 * Калькулятор КБЖУ (Калории, Белки, Жиры, Углеводы)
 * Использует формулу Mifflin-St Jeor для расчёта BMR
 */

export type Sex = 'Мужчина' | 'Женщина';

export type ActivityLevel = 
  | 'Сидячая работа' 
  | 'Небольшая активность' 
  | 'Умеренная' 
  | 'Высокая';

export type Goal = 
  | 'Похудеть' 
  | 'Набрать массу' 
  | 'Поддержание веса' 
  | 'Сушка';

export interface Profile {
  sex: Sex;
  weight_kg: number;
  height_cm: number;
  age: number;
  activity_level?: ActivityLevel;
  training_per_week?: number;
  goal: Goal;
}

export interface Macros {
  protein_g: number;
  fats_g: number;
  carbs_g: number;
}

export interface CalculationResult {
  bmr: number;           // Базовый метаболизм (Basal Metabolic Rate)
  tdee: number;          // Общий расход энергии (Total Daily Energy Expenditure)
  target_kcal: number;   // Целевые калории с учётом цели
  macros: Macros;        // Распределение макронутриентов
}

/**
 * Расчёт BMR по формуле Mifflin-St Jeor
 * BMR = (10 × вес_кг) + (6.25 × рост_см) - (5 × возраст) + s
 * где s = +5 для мужчин, -161 для женщин
 */
export function mifflinStJeor(profile: Profile): number {
  const { weight_kg, height_cm, age, sex } = profile;
  const s = sex === 'Мужчина' ? 5 : -161;
  const bmr = (10 * weight_kg) + (6.25 * height_cm) - (5 * age) + s;
  return Math.round(bmr);
}

/**
 * Коэффициент активности для расчёта TDEE
 */
export function activityMultiplier(level: ActivityLevel = 'Сидячая работа'): number {
  const multipliers: Record<ActivityLevel, number> = {
    'Сидячая работа': 1.2,
    'Небольшая активность': 1.375,
    'Умеренная': 1.55,
    'Высокая': 1.725
  };
  return multipliers[level];
}

/**
 * Расчёт целевых калорий с учётом цели
 */
function applyGoalMultiplier(tdee: number, goal: Goal): number {
  const multipliers: Record<Goal, number> = {
    'Похудеть': 0.85,        // Дефицит 15%
    'Набрать массу': 1.15,   // Профицит 15%
    'Поддержание веса': 1.0, // Без изменений
    'Сушка': 0.8             // Дефицит 20%
  };
  return Math.round(tdee * multipliers[goal]);
}

/**
 * Распределение макронутриентов по соотношению P30/F25/C45
 * Белки: 30% от калорий (4 ккал/г)
 * Жиры: 25% от калорий (9 ккал/г)
 * Углеводы: 45% от калорий (4 ккал/г)
 */
function calculateMacros(targetKcal: number): Macros {
  const proteinKcal = targetKcal * 0.30;
  const fatsKcal = targetKcal * 0.25;
  const carbsKcal = targetKcal * 0.45;

  return {
    protein_g: Math.round(proteinKcal / 4),
    fats_g: Math.round(fatsKcal / 9),
    carbs_g: Math.round(carbsKcal / 4)
  };
}

/**
 * Основная функция расчёта КБЖУ
 */
export function calculateTarget(profile: Profile): CalculationResult {
  // Валидация входных данных
  if (profile.weight_kg <= 0 || profile.height_cm <= 0 || profile.age <= 0) {
    throw new Error('Некорректные параметры профиля');
  }

  // 1. Расчёт BMR
  const bmr = mifflinStJeor(profile);

  // 2. Расчёт TDEE
  const activity = profile.activity_level || 'Сидячая работа';
  const multiplier = activityMultiplier(activity);
  const tdee = Math.round(bmr * multiplier);

  // 3. Применение цели (дефицит/профицит)
  const target_kcal = applyGoalMultiplier(tdee, profile.goal);

  // 4. Расчёт макронутриентов
  const macros = calculateMacros(target_kcal);

  return {
    bmr,
    tdee,
    target_kcal,
    macros
  };
}

/**
 * Вспомогательная функция для форматирования результата
 */
export function formatResult(result: CalculationResult): string {
  return `
КБЖУ расчёт:
- BMR: ${result.bmr} ккал
- TDEE: ${result.tdee} ккал
- Целевые калории: ${result.target_kcal} ккал
- Белки: ${result.macros.protein_g} г
- Жиры: ${result.macros.fats_g} г
- Углеводы: ${result.macros.carbs_g} г
  `.trim();
}



