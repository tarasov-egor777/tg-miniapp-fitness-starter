# n8n Workflow для Telegram Mini App

Этот workflow обрабатывает анкеты пользователей, рассчитывает КБЖУ, генерирует план питания и отправляет PDF через Telegram.

## Установка

1. Импортируйте `workflow.json` в ваш n8n instance
2. Настройте переменные окружения в n8n:
   - `SUPABASE_URL` - URL вашего Supabase проекта
   - `SUPABASE_ANON_KEY` - Anon ключ Supabase
   - `SUPABASE_SERVICE_KEY` - Service Role ключ (для записи)
   - `TELEGRAM_BOT_TOKEN` - Токен Telegram бота
   - `CALCULATOR_API_URL` - URL вашего API калькулятора
   - `PDF_GENERATOR_URL` - URL сервиса генерации PDF
   - `STORAGE_URL` - URL хранилища для PDF (S3/GDrive)
   - `STORAGE_TOKEN` - Токен для доступа к хранилищу

3. Активируйте workflow и скопируйте webhook URL

4. Настройте webhook URL в вашем Telegram боте или frontend приложении

## Описание шагов

1. **Webhook: Submit Profile** - Принимает данные анкеты от пользователя
2. **Validate Profile Data** - Проверяет корректность данных
3. **Save Profile to Supabase** - Сохраняет профиль в БД
4. **Calculate KBJU** - Вызывает API для расчёта КБЖУ
5. **Find Recipes** - Ищет подходящие рецепты (требует доработки)
6. **Generate PDF** - Генерирует PDF файл с планом
7. **Upload PDF to Storage** - Загружает PDF в облачное хранилище
8. **Send PDF via Telegram** - Отправляет PDF пользователю через Bot API
9. **Respond Success/Error** - Возвращает ответ webhook'у

## Доработки

- Добавьте поиск рецептов из Supabase в шаге "Find Recipes"
- Настройте генерацию PDF (puppeteer, docx, или внешний сервис)
- Добавьте обработку ошибок и retry логику
- Добавьте шаг для обработки платежей перед генерацией плана



