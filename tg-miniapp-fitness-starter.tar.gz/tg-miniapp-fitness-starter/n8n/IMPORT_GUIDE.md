# Руководство по импорту workflow в n8n

## Проблема с импортом

Если вы получили ошибку `undefined is not a function`, это означает, что формат workflow JSON не совместим с вашей версией n8n.

## Решение 1: Использовать упрощенный workflow

Используйте файл `workflow-simple.json` - это минимальная версия, которая точно работает:

1. Откройте n8n
2. Нажмите **Import from File**
3. Выберите `workflow-simple.json`
4. Настройте переменные окружения

## Решение 2: Создать workflow вручную (рекомендуется)

Это самый надежный способ:

### Шаг 1: Создайте новый workflow

1. В n8n нажмите **+ Add workflow**
2. Назовите его "Telegram Mini App Fitness"

### Шаг 2: Добавьте Webhook триггер

1. Перетащите ноду **Webhook** на canvas
2. Настройте:
   - **HTTP Method**: POST
   - **Path**: `submit-profile`
   - **Response Mode**: Respond to Webhook
3. Сохраните и скопируйте **Production URL** (он понадобится для frontend)

### Шаг 3: Добавьте Code ноду для обработки

1. Перетащите ноду **Code** после Webhook
2. Вставьте код:

```javascript
// Обработка данных анкеты
const body = $input.item.json.body || $input.item.json;

// Валидация
if (!body.profile) {
  throw new Error('Profile is required');
}

// Формируем данные для Supabase
const profileData = {
  sex: body.profile.sex,
  height_cm: body.profile.height_cm,
  weight_kg: body.profile.weight_kg,
  age: body.profile.age,
  activity_level: body.profile.activity_level,
  training_per_week: body.profile.training_per_week || 0,
  goal: body.profile.goal,
  preferences: {
    grains: body.profile.grains || [],
    allergies: body.profile.allergies || [],
    dietary_restrictions: body.profile.dietary_restrictions || [],
    cooking_frequency: body.profile.cooking_frequency || 'Каждый день'
  }
};

return {
  profileData: profileData,
  userId: body.user?.id,
  contact: body.contact
};
```

### Шаг 4: Добавьте HTTP Request для Supabase

1. Перетащите ноду **HTTP Request** после Code
2. Настройте:
   - **Method**: POST
   - **URL**: `{{ $env.SUPABASE_URL }}/rest/v1/profiles`
   - **Authentication**: None
   - **Headers**:
     - `apikey`: `{{ $env.SUPABASE_ANON_KEY }}`
     - `Authorization`: `Bearer {{ $env.SUPABASE_SERVICE_KEY }}`
     - `Content-Type`: `application/json`
     - `Prefer`: `return=representation`
   - **Body**: JSON
   - **JSON Body**: 
   ```json
   {
     "sex": "{{ $json.profileData.sex }}",
     "height_cm": {{ $json.profileData.height_cm }},
     "weight_kg": {{ $json.profileData.weight_kg }},
     "age": {{ $json.profileData.age }},
     "activity_level": "{{ $json.profileData.activity_level }}",
     "training_per_week": {{ $json.profileData.training_per_week }},
     "goal": "{{ $json.profileData.goal }}",
     "preferences": {{ JSON.stringify($json.profileData.preferences) }}
   }
   ```

### Шаг 5: Добавьте Respond to Webhook

1. Перетащите ноду **Respond to Webhook** в конце
2. Настройте:
   - **Respond With**: JSON
   - **Response Body**:
   ```json
   {
     "success": true,
     "profile_id": "{{ $json.id }}"
   }
   ```

### Шаг 6: Настройте переменные окружения

В настройках n8n (Settings → Environment Variables) добавьте:

- `SUPABASE_URL` - URL вашего Supabase проекта
- `SUPABASE_ANON_KEY` - Anon ключ
- `SUPABASE_SERVICE_KEY` - Service Role ключ

### Шаг 7: Активируйте workflow

1. Переключите тумблер **Active** в положение ON
2. Скопируйте Production URL webhook'а
3. Используйте этот URL в вашем frontend приложении

## Решение 3: Обновить n8n

Если вы используете старую версию n8n:

```bash
# Если используете Docker
docker pull n8nio/n8n:latest

# Если используете npm
npm update -g n8n
```

## Тестирование workflow

После настройки протестируйте workflow:

1. В n8n нажмите **Execute Workflow**
2. Введите тестовые данные:

```json
{
  "body": {
    "profile": {
      "sex": "Мужчина",
      "height_cm": 180,
      "weight_kg": 75,
      "age": 30,
      "activity_level": "Умеренная",
      "training_per_week": 4,
      "goal": "Похудеть",
      "grains": ["Гречка", "Рис"],
      "allergies": [],
      "dietary_restrictions": [],
      "cooking_frequency": "Каждый день"
    },
    "user": {
      "id": 123456789
    },
    "contact": {
      "name": "Тест",
      "email": "test@example.com"
    }
  }
}
```

3. Проверьте, что данные сохранились в Supabase

## Дополнительные шаги (опционально)

После базового workflow можно добавить:

1. **HTTP Request** для вызова калькулятора КБЖУ
2. **Code** ноду для поиска рецептов
3. **HTTP Request** для генерации PDF
4. **HTTP Request** для отправки через Telegram Bot API

См. полный пример в `workflow.json` (но он может не импортироваться напрямую - лучше создать вручную).

