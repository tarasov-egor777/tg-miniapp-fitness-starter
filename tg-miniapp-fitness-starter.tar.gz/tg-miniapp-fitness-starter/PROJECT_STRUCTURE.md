# Структура проекта

Полное описание созданных файлов и их назначения.

## 📁 Корневая директория

- `README.md` - Основная документация проекта
- `QUICKSTART.md` - Пошаговая инструкция по запуску
- `PROJECT_STRUCTURE.md` - Этот файл
- `.gitignore` - Игнорируемые файлы для Git
- `.env.example` - Шаблон переменных окружения (заблокирован для редактирования)

## 📁 webapp/ - Frontend (React + Vite)

Telegram Web App с мультишаговой анкетой.

### Основные файлы:

- `package.json` - Зависимости и скрипты
- `vite.config.js` - Конфигурация Vite
- `index.html` - HTML шаблон с подключением Telegram Web App API

### src/:

- `main.jsx` - Точка входа React приложения
- `App.jsx` - Главный компонент приложения
- `App.css` - Стили для App
- `index.css` - Глобальные стили
- `telegram.js` - Интеграция с Telegram.WebApp API
  - `initTelegram()` - Инициализация Web App
  - `sendDataToBot()` - Отправка данных боту
  - `showAlert()` - Показ уведомлений
  - `getUserData()` - Получение данных пользователя

### src/components/:

- `StepForm.jsx` - Мультишаговая форма анкеты
  - Шаг 1: Основные данные (пол, рост, вес, возраст)
  - Шаг 2: Цель и активность (цель, уровень активности, крупы)
  - Шаг 3: Аллергии и ограничения
  - Шаг 4: Контакты (имя, email, телефон)
  - Шаг 5: Подтверждение и отправка
- `StepForm.css` - Стили для формы

## 📁 api/ - Backend (TypeScript)

API модули для расчёта КБЖУ и обработки запросов.

### Основные файлы:

- `package.json` - Зависимости и скрипты (vitest для тестов)
- `tsconfig.json` - Конфигурация TypeScript
- `vitest.config.ts` - Конфигурация тестов

### src/:

- `calculator.ts` - Модуль расчёта КБЖУ
  - `mifflinStJeor()` - Расчёт BMR по формуле Mifflin-St Jeor
  - `activityMultiplier()` - Коэффициенты активности
  - `calculateTarget()` - Основная функция расчёта
  - Типы: `Profile`, `Macros`, `CalculationResult`
- `index.ts` - HTTP endpoint stub для интеграции с n8n

### test/:

- `calculator.test.ts` - Unit-тесты для калькулятора
  - Тесты BMR для мужчин и женщин
  - Тесты коэффициентов активности
  - Тесты расчёта целевых калорий
  - Тесты распределения макронутриентов

## 📁 infra/ - Инфраструктура

SQL миграции для Supabase.

### migrations/:

- `001_init.sql` - Базовая структура БД
  - Таблица `users` - Пользователи из Telegram
  - Таблица `profiles` - Профили и анкеты
  - Таблица `recipes` - База рецептов
  - Таблица `plans` - Планы питания
  - Таблица `plans_versions` - История версий планов
  - Таблица `payments` - Платежи
  - RLS политики безопасности
  - Триггеры для `updated_at`
- `002_vector_extension.sql` - Расширение для векторного поиска
  - Таблица `recipes_vector` - Эмбеддинги рецептов
  - Функция `search_similar_recipes()` - Поиск похожих рецептов

## 📁 n8n/ - Оркестрация

Workflow для автоматизации процессов.

- `workflow.json` - Экспорт n8n workflow
  - Webhook триггер
  - Валидация данных
  - Сохранение в Supabase
  - Расчёт КБЖУ
  - Поиск рецептов
  - Генерация PDF
  - Загрузка в хранилище
  - Отправка через Telegram
- `README.md` - Инструкции по настройке n8n

## 🔧 Переменные окружения

### webapp/.env:

```env
VITE_SUPABASE_URL=...
VITE_SUPABASE_ANON_KEY=...
VITE_WEBHOOK_URL=...
```

### api/.env:

```env
SUPABASE_URL=...
SUPABASE_SERVICE_KEY=...
TELEGRAM_BOT_TOKEN=...
PORT=3001
```

## 🚀 Команды для запуска

### Frontend:

```bash
cd webapp
npm install
npm run dev      # Запуск dev-сервера
npm run build    # Production сборка
npm run preview  # Превью production
```

### Backend:

```bash
cd api
npm install
npm test         # Запуск тестов
npm run test:watch  # Тесты в watch режиме
npm run build    # Компиляция TypeScript
```

## 📊 Алгоритм работы

1. **Пользователь** заполняет анкету в Telegram Web App
2. **Frontend** отправляет данные через `Telegram.WebApp.sendData()` или webhook
3. **n8n** получает webhook и запускает workflow:
   - Валидация данных
   - Сохранение профиля в Supabase
   - Вызов API для расчёта КБЖУ
   - Поиск подходящих рецептов
   - Генерация PDF с планом
   - Загрузка PDF в хранилище
   - Отправка PDF пользователю через Telegram Bot API
4. **Пользователь** получает индивидуальный план питания

## 🔐 Безопасность

- ✅ Service Role ключ Supabase - только в backend/n8n
- ✅ Anon ключ - только в frontend (read-only)
- ✅ RLS политики в Supabase для защиты данных
- ✅ Валидация данных на всех уровнях
- ✅ Telegram Web App API для безопасной передачи данных

## 📝 Следующие шаги для доработки

1. Добавить рецепты в базу данных
2. Реализовать поиск рецептов по векторному сходству
3. Настроить генерацию PDF (puppeteer/docx)
4. Интегрировать платежи (Telegram Payments/Stripe)
5. Добавить админ-панель для тренеров
6. Реализовать версионирование планов
7. Добавить A/B тесты и метрики



