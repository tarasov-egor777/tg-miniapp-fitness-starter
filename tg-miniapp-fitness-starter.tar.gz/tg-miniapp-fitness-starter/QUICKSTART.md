# Быстрый старт

Пошаговая инструкция по запуску проекта в Cursor.

## Шаг 1: Установка зависимостей

```bash
# Frontend
cd webapp
npm install

# Backend
cd ../api
npm install
```

## Шаг 2: Настройка переменных окружения

### Webapp

Создайте файл `webapp/.env`:

```env
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your_anon_key_here
VITE_WEBHOOK_URL=https://your-n8n-instance.com/webhook/submit
```

### API

Создайте файл `api/.env`:

```env
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_KEY=your_service_role_key_here
TELEGRAM_BOT_TOKEN=your_bot_token_here
PORT=3001
```

## Шаг 3: Настройка Supabase

1. Создайте проект на [supabase.com](https://supabase.com)
2. Откройте SQL Editor
3. Выполните миграции по порядку:
   - `infra/migrations/001_init.sql`
   - `infra/migrations/002_vector_extension.sql` (опционально, если нужен векторный поиск)

## Шаг 4: Настройка Telegram Bot

1. Создайте бота через [@BotFather](https://t.me/BotFather)
2. Получите токен и добавьте в `api/.env`
3. Настройте Web App:
   ```
   /newapp
   [название вашего бота]
   [описание]
   [фото, если нужно]
   [webapp URL после деплоя]
   ```

## Шаг 5: Запуск локально

### Frontend (dev режим)

```bash
cd webapp
npm run dev
```

Откройте в браузере: `http://localhost:3000`

### Backend (тесты)

```bash
cd api
npm test
```

## Шаг 6: Настройка n8n

1. Импортируйте `n8n/workflow.json` в ваш n8n instance
2. Настройте переменные окружения в n8n (см. `n8n/README.md`)
3. Активируйте workflow и скопируйте webhook URL
4. Добавьте webhook URL в `webapp/.env` как `VITE_WEBHOOK_URL`

## Шаг 7: Тестирование

1. Запустите webapp: `cd webapp && npm run dev`
2. Откройте в Telegram (через бота) или в браузере
3. Заполните анкету и отправьте
4. Проверьте, что данные приходят в n8n webhook

## Следующие шаги

- ✅ Настройте генерацию PDF (puppeteer или внешний сервис)
- ✅ Добавьте рецепты в базу данных Supabase
- ✅ Настройте платежи (Telegram Payments или Stripe)
- ✅ Деплой frontend (Vercel/Netlify)
- ✅ Деплой backend API (Vercel Functions/Railway)

## Полезные команды

```bash
# Запуск тестов с watch режимом
cd api && npm run test:watch

# Production сборка frontend
cd webapp && npm run build

# Просмотр production сборки
cd webapp && npm run preview
```



